$ErrorActionPreference='Continue'
$root=$PSScriptRoot; Set-Location $root
$env:JAVA_HOME="D:\Programs\Portable Android Build\jdk"; $j="$env:JAVA_HOME\bin"
$sdk="D:\Programs\Portable Android Build\sdk"; $bt="$sdk\build-tools\36.0.0"
$aj="$sdk\platforms\android-36\android.jar"
$libs="D:\Programs\___Source Code___\OneHandOperationPlusPort\libs"
$cp="$aj;$libs\api.jar;$libs\provider.jar;$libs\shared.jar;$libs\aidl.jar;$libs\hab.jar"
if(!(Test-Path key.jks)){ & "$j\keytool.exe" -genkeypair -keystore key.jks -storepass oneui123 -keypass oneui123 -alias oneui -keyalg RSA -keysize 2048 -validity 36500 -dname "CN=Leshugan" 2>&1 | Out-Null }
$b="$env:TEMP\oneui_build"; if(Test-Path $b){ Remove-Item $b -Recurse -Force }
New-Item -ItemType Directory "$b\res","$b\cls","$b\gen","$b\dex" -Force | Out-Null

& "$bt\aapt2.exe" compile --dir res -o "$b\res\res.zip" 2>&1 | % { "$_" }
& "$bt\aapt2.exe" link -o "$b\base.apk" -I $aj --manifest AndroidManifest.xml --java "$b\gen" --auto-add-overlay "$b\res\res.zip" 2>&1 | % { "$_" }
if(!(Test-Path "$b\base.apk")){ throw "aapt2 link failed" }

$srcs=@((Get-ChildItem src -Recurse -Filter *.java).FullName) + @((Get-ChildItem "$b\gen" -Recurse -Filter *.java).FullName)
& "$j\javac.exe" -nowarn --release 11 -encoding UTF-8 -cp $cp -d "$b\cls" $srcs 2>&1 | % { "$_" }
if($LASTEXITCODE -ne 0){ throw "javac failed" }
$cls=@((Get-ChildItem "$b\cls" -Recurse -Filter *.class).FullName)
if($cls.Count -eq 0){ throw "javac failed" }
& "$j\java.exe" -cp "$bt\lib\d8.jar" com.android.tools.r8.D8 --release --min-api 34 --lib $aj --output "$b\dex" $cls "$libs\api.jar" "$libs\provider.jar" "$libs\shared.jar" "$libs\aidl.jar" "$libs\hab.jar" 2>&1 | Select-String -NotMatch "^Warning" | % { "$_" }
if(!(Test-Path "$b\dex\classes.dex")){ throw "d8 failed" }

Copy-Item "$b\base.apk" "$b\un.apk"
Add-Type -A System.IO.Compression.FileSystem
$z=[IO.Compression.ZipFile]::Open("$b\un.apk",'Update')
Get-ChildItem "$b\dex" -Filter *.dex | % { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($z,$_.FullName,$_.Name) }
$z.Dispose()
& "$bt\zipalign.exe" -f -p 4 "$b\un.apk" "$b\al.apk"
& "$bt\apksigner.bat" sign --ks key.jks --ks-pass pass:oneui123 --key-pass pass:oneui123 --out "$root\OneUIRecents.apk" "$b\al.apk"
Remove-Item $b -Recurse -Force
if(Test-Path "$root\OneUIRecents.apk.idsig"){ Remove-Item "$root\OneUIRecents.apk.idsig" }
"built"
