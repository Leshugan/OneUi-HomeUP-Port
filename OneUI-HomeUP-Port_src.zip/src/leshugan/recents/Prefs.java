package leshugan.recents;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** All user settings. Layout ids follow One UI Home (RecentsConstants). */
public final class Prefs {
    public static final int LIST = 0, GRID = 1, VERTICAL = 3, SLIM = 4, TILT = 5;
    public static final int[] LAYOUTS = {LIST, GRID, VERTICAL, SLIM, TILT};

    public static final String ENABLED = "enabled";
    public static final String LAYOUT = "layout";
    public static final String MINI = "mini";
    public static final String CENTER = "center";
    public static final String LABEL = "label";
    public static final String CIRCULAR = "circular";
    public static final String SEARCH = "search";
    public static final String ICONBAR = "iconbar";
    public static final String ROUND = "round_icons";
    public static final String LOCKED = "locked";
    public static final String ORDER = "order";
    public static final String HIDDEN = "hidden";

    public static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("prefs", Context.MODE_PRIVATE);
    }

    public static boolean enabled(Context c) { return sp(c).getBoolean(ENABLED, true); }
    public static int layout(Context c) { return sp(c).getInt(LAYOUT, TILT); }
    public static boolean mini(Context c) { return sp(c).getBoolean(MINI, false); }
    public static boolean center(Context c) { return sp(c).getBoolean(CENTER, false); }
    public static boolean label(Context c) { return sp(c).getBoolean(LABEL, false); }
    public static boolean circular(Context c) { return sp(c).getBoolean(CIRCULAR, false); }
    public static boolean search(Context c) { return sp(c).getBoolean(SEARCH, true); }
    public static boolean iconBar(Context c) { return sp(c).getBoolean(ICONBAR, true); }
    public static boolean round(Context c) { return sp(c).getBoolean(ROUND, false); }

    public static Set<String> locked(Context c) {
        return new HashSet<>(sp(c).getStringSet(LOCKED, new HashSet<>()));
    }

    public static void setLocked(Context c, String pkg, boolean on) {
        Set<String> s = locked(c);
        if (on) s.add(pkg); else s.remove(pkg);
        sp(c).edit().putStringSet(LOCKED, s).apply();
    }

    private Prefs() {}
}
