package leshugan.recents;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Small picture of one recents layout for the settings screen. */
public final class PreviewView extends View {
    private static final int[] ICONS = {0xFF3E8BFF, 0xFF2BC46B, 0xFFFFB300, 0xFFFF5A5F, 0xFF8E6CFF, 0xFF00B8D4, 0xFFFF7A00};
    private final int layout;
    private final float dp;
    private boolean selected;
    private int accent = 0xFF2F80ED;
    private final Paint p = Tasks.aa(), bg = Tasks.aa(), sel = Tasks.aa();
    private final RectF r = new RectF();

    public PreviewView(Context c, int layout) {
        super(c);
        this.layout = layout;
        dp = getResources().getDisplayMetrics().density;
        sel.setStyle(Paint.Style.STROKE);
        sel.setStrokeWidth(2.5f * dp);
    }

    public void setSelectedState(boolean s, int accent) { selected = s; this.accent = accent; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        float W = getWidth(), H = getHeight(), pad = 3 * dp;
        float w = W - 2 * pad, h = H - 2 * pad;
        c.save();
        c.translate(pad, pad);
        r.set(0, 0, w, h);
        bg.setShader(new LinearGradient(0, 0, 0, h, new int[]{0xFF9DB4D8, 0xFFC9A9C9, 0xFFE58FA0}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 12 * dp, 12 * dp, bg);
        c.clipRect(0, 0, w, h);
        switch (layout) {
            case Prefs.LIST: {
                float cw = 0.6f * w, ch = 0.6f * h, top = 0.17f * h, gap = 0.056f * w;
                card(c, (w - cw) / 2f - cw - gap, top + ch * 0.05f, cw, ch * 0.9f);
                card(c, (w + cw) / 2f + gap, top + ch * 0.05f, cw, ch * 0.9f);
                card(c, (w - cw) / 2f, top, cw, ch);
                icon(c, w / 2f, top - 6 * dp, 4.5f * dp, 1);
                break;
            }
            case Prefs.GRID: {
                float cw = 0.29f * w, ch = 0.29f * h, gap = 0.04f * w, top = 0.15f * h;
                for (int col = 0; col < 3; col++) for (int row = 0; row < 2; row++) {
                    float right = 0.91f * w - col * (cw + gap);
                    float t = top + row * (ch + 0.06f * h);
                    card(c, right - cw, t, cw, ch);
                    icon(c, right - cw / 2f, t, 3.5f * dp, col * 2 + row);
                }
                break;
            }
            case Prefs.VERTICAL: {
                float cw = 0.542f * w, ch = 0.2f * h, gap = 0.026f * h;
                for (int i = 0; i < 3; i++) {
                    float t = 0.59f * h - i * (ch + gap);
                    card(c, 0.367f * w, t, cw, ch);
                    icon(c, 0.1f * w, t + 4 * dp, 3.2f * dp, i);
                    bar(c, 0.1f * w + 5 * dp, t + 2.8f * dp, 0.15f * w);
                }
                break;
            }
            case Prefs.SLIM: {
                float cw = 0.9f * w, ch = 0.077f * h, gap = 0.018f * h;
                for (int i = 0; i < 7; i++) {
                    float t = 0.68f * h - i * (ch + gap);
                    p.setColor(0xE6F4F4F6);
                    r.set((w - cw) / 2f, t, (w + cw) / 2f, t + ch);
                    c.drawRoundRect(r, ch / 2f, ch / 2f, p);
                    icon(c, (w - cw) / 2f + 7 * dp, t + ch / 2f, 3f * dp, i);
                    p.setColor(0xFF9AA1AA);
                    r.set((w - cw) / 2f + 12 * dp, t + ch / 2f - 1.2f * dp, (w - cw) / 2f + 12 * dp + 0.22f * w, t + ch / 2f + 1.2f * dp);
                    c.drawRoundRect(r, dp, dp, p);
                }
                break;
            }
            default: { // TILT
                float cw = 0.631f * w, ch = 0.631f * h, top = 0.15f * h, cl = (w - cw) / 2f;
                c.save();
                c.rotate(-4, cl - 0.144f * w + cw * 0.45f, top + ch / 2f);
                card(c, cl - 0.144f * w, top + ch * 0.05f, cw * 0.9f, ch * 0.9f);
                c.restore();
                card(c, cl + cw + 0.044f * w, top - ch * 0.025f, cw * 1.05f, ch * 1.05f);
                card(c, cl, top, cw, ch);
                icon(c, w / 2f, top, 4.5f * dp, 2);
                break;
            }
        }
        p.setColor(0x99FFFFFF);
        float pw = 0.42f * w, ph = 0.045f * h, py = 0.86f * h;
        r.set((w - pw) / 2f, py, (w + pw) / 2f, py + ph);
        c.drawRoundRect(r, ph / 2f, ph / 2f, p);
        c.restore();
        if (selected) {
            sel.setColor(accent);
            r.set(1.25f * dp, 1.25f * dp, W - 1.25f * dp, H - 1.25f * dp);
            c.drawRoundRect(r, 14 * dp, 14 * dp, sel);
        }
    }

    private void card(Canvas c, float x, float y, float w, float h) {
        p.setColor(0xFFFFFFFF);
        r.set(x, y, x + w, y + h);
        float rad = Math.min(w, h) * 0.1f;
        c.drawRoundRect(r, rad, rad, p);
        p.setColor(0xFFE4E7EC);
        float m = w * 0.12f;
        for (int i = 0; i < 3; i++) {
            float ly = y + h * 0.18f + i * h * 0.12f;
            if (ly + 2 * dp > y + h - m) break;
            r.set(x + m, ly, x + w - m - (i == 2 ? w * 0.3f : 0), ly + Math.max(1.5f * dp, h * 0.04f));
            c.drawRoundRect(r, dp, dp, p);
        }
    }

    private void icon(Canvas c, float cx, float cy, float rad, int k) {
        p.setColor(ICONS[k % ICONS.length]);
        c.drawCircle(cx, cy, rad, p);
    }

    private void bar(Canvas c, float x, float y, float w) {
        p.setColor(0xCCFFFFFF);
        r.set(x, y, x + w, y + 2.4f * dp);
        c.drawRoundRect(r, dp, dp, p);
    }
}
