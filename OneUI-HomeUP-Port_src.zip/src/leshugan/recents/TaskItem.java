package leshugan.recents;

import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

public final class TaskItem {
    public int taskId = -1;          // -1 when the list comes from usage history (no Shizuku)
    public String pkg;
    public ComponentName comp;
    public Intent baseIntent;
    public String label;
    public Drawable icon;
    public volatile Bitmap thumb;
    public int color;                 // card colour when there is no thumbnail
    public long lastActive;
    public boolean locked;
    public int recency;
    public Bitmap round;              // circular copy of the icon (made on first use)               // 0 = used last

    public String key() { return taskId >= 0 ? "t" + taskId : "p" + pkg; }
}
