package leshugan.recents;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The One UI style recent apps screen. */
public final class RecentsActivity extends Activity implements DeckView.Host {
    public static final String ACTION_SHOW = "leshugan.recents.SHOW";
    public static final String ACTION_TOGGLE = "leshugan.recents.TOGGLE";
    public static final String ACTION_QUICK = "leshugan.recents.QUICK";
    public static final String EXTRA_FG = "fg";
    public static final String EXTRA_HOME = "home";

    static volatile boolean visible;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private ExecutorService io;
    private DeckView deck;
    private FrameLayout root, back;
    private TextView closeAll, empty;
    private ImageView searchBtn;
    private LinearLayout topBar;
    private float dp;
    private boolean night, fromApp, leaving;
    private String currentKey, prevKey;
    private int navBottom;
    private PopupWindow popup;
    private List<TaskItem> all = new ArrayList<>();
    private final List<TaskItem> bgList = new ArrayList<>();
    private TextView bgChip;
    private FrameLayout sheet;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        io = Executors.newSingleThreadExecutor();

        getWindow().setDecorFitsSystemWindows(false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        try { getWindow().setBackgroundBlurRadius(Math.round(60 * dp)); } catch (Throwable ignored) {}
        WindowManager.LayoutParams wlp = getWindow().getAttributes();
        wlp.preferredRefreshRate = 120f;
        getWindow().setAttributes(wlp);

        root = new FrameLayout(this);
        back = new FrameLayout(this);
        root.addView(back, new FrameLayout.LayoutParams(-1, -1));
        boolean sysBlur = getWindowManager().isCrossWindowBlurEnabled();
        if (sysBlur || !addOwnBlur()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        View dim = new View(this);
        dim.setBackgroundColor(night ? 0x73000000 : 0x38000000);
        back.addView(dim, new FrameLayout.LayoutParams(-1, -1));
        Tasks.ensureBinder(this);
        deck = new DeckView(this, this);
        try { deck.setRequestedFrameRate(View.REQUESTED_FRAME_RATE_CATEGORY_HIGH); } catch (Throwable ignored) {}
        deck.applyPrefs();
        root.addView(deck, new FrameLayout.LayoutParams(-1, -1));

        empty = new TextView(this);
        empty.setText("Нет недавних приложений");
        empty.setTextColor(Color.WHITE);
        empty.setGravity(Gravity.CENTER);
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        empty.setShadowLayer(3 * dp, 0, dp, 0x66000000);
        empty.setVisibility(View.GONE);
        root.addView(empty, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        closeAll = new TextView(this);
        closeAll.setText("Закрыть все");
        closeAll.setGravity(Gravity.CENTER);
        closeAll.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        closeAll.setMinWidth(Math.round(190 * dp));
        closeAll.setPadding(Math.round(22 * dp), 0, Math.round(22 * dp), 0);
        styleCloseAll();
        // One UI «recoil»: the button shrinks a little while pressed
        closeAll.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(120).start();
            else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(200).start();
            return false;
        });
        closeAll.setOnClickListener(v -> deck.closeAll(this::goHome));
        root.addView(closeAll, new FrameLayout.LayoutParams(-2, Math.round(44 * dp), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBtn = topButton(R.drawable.ic_search, v -> openSearch());
        topBar.addView(searchBtn);
        topBar.addView(topButton(R.drawable.ic_more, this::openMore));
        root.addView(topBar, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));

        bgChip = new TextView(this);
        bgChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        bgChip.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        bgChip.setGravity(Gravity.CENTER);
        bgChip.setMinWidth(Math.round(64 * dp));
        bgChip.setPadding(Math.round(12 * dp), 0, Math.round(12 * dp), 0);
        bgChip.setVisibility(View.GONE);
        bgChip.setOnClickListener(v -> openBgSheet());
        FrameLayout.LayoutParams cpl = new FrameLayout.LayoutParams(-2, Math.round(36 * dp), Gravity.TOP | Gravity.START);
        root.addView(bgChip, cpl);

        root.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets s = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            deck.setInsets(s.top, s.bottom);
            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) closeAll.getLayoutParams();
            p.bottomMargin = s.bottom + Math.round(31 * dp);
            closeAll.setLayoutParams(p);
            FrameLayout.LayoutParams t = (FrameLayout.LayoutParams) topBar.getLayoutParams();
            t.topMargin = s.top + Math.round(4 * dp);
            t.rightMargin = s.right + Math.round(8 * dp);
            topBar.setLayoutParams(t);
            FrameLayout.LayoutParams cp = (FrameLayout.LayoutParams) bgChip.getLayoutParams();
            cp.topMargin = s.top + Math.round(10 * dp);
            cp.leftMargin = s.left + Math.round(16 * dp);
            bgChip.setLayoutParams(cp);
            navBottom = s.bottom;
            return in;
        });
        setContentView(root);
        WindowInsetsController ic = getWindow().getInsetsController();
        if (ic != null) ic.setSystemBarsAppearance(0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        open(getIntent());
    }

    /** System blur is switched off on this phone: draw the wallpaper blurred ourselves. False when it is unavailable. */
    private boolean addOwnBlur() {
        android.graphics.Bitmap b = Wallpaper.get(this);
        if (b == null) b = Wallpaper.load(this);
        if (b == null) return false;
        ImageView bgv = new ImageView(this);
        bgv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgv.setImageBitmap(b);
        back.addView(bgv, new FrameLayout.LayoutParams(-1, -1));
        return true;
    }
    /** Colours of the One UI «Close all» button (One UI Home: clear_all_bg). */
    private void styleCloseAll() {
        int lay = Prefs.layout(this);
        boolean flat = lay == Prefs.VERTICAL || lay == Prefs.SLIM;
        int bg = night ? 0x571C1C1C : (flat ? 0x57737373 : 0x33FCFCFC);
        int stroke = night || flat ? 0x4DFCFCFC : 0;
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(22 * dp);
        d.setColor(bg);
        if (stroke != 0) d.setStroke(Math.max(1, Math.round(dp)), stroke);
        closeAll.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), d, null));
        closeAll.setTextColor(night ? 0xE6FAFAFA : 0xFFFAFAFA);
    }

    private ImageView topButton(int icon, View.OnClickListener l) {
        ImageView v = new ImageView(this);
        v.setImageResource(icon);
        v.setScaleType(ImageView.ScaleType.CENTER);
        v.setColorFilter(Color.WHITE);
        int s = Math.round(48 * dp);
        v.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true);
        v.setBackgroundResource(tv.resourceId);
        v.setOnClickListener(l);
        return v;
    }

    private void open(Intent i) {
        leaving = false;
        deck.resetExit();
        deck.applyPrefs();
        searchBtn.setVisibility(Prefs.search(this) ? View.VISIBLE : View.GONE);
        styleCloseAll();
        String fg = i != null ? i.getStringExtra(EXTRA_FG) : null;
        List<TaskItem> list = Tasks.load(this);
        all = new ArrayList<>(list);
        bgList.clear();
        if (Tasks.isOplus()) {
            List<TaskItem> vis = new ArrayList<>();
            for (TaskItem t : list) { if (t.locked) bgList.add(t); else vis.add(t); }
            list = vis;
        }
        closeSheet(false);
        TaskItem cur = null, prev = null;
        for (TaskItem t : list) { if (t.recency == 0) cur = t; else if (prev == null || t.recency < prev.recency) prev = t; }
        boolean fromHome = i != null && i.getBooleanExtra(EXTRA_HOME, false);
        fromApp = cur != null && !fromHome && (fg == null || !i.hasExtra(EXTRA_HOME) ? (fg == null || fg.equals(cur.pkg)) : true);
        currentKey = fromApp ? cur.key() : null;
        boolean bigThumb = false;
        if (fromApp && cur.taskId >= 0) {
            android.graphics.Bitmap bm = Tasks.snapshot(cur, true, getResources().getDisplayMetrics().widthPixels);
            if (bm != null) cur.thumb = bm;
            bigThumb = cur.thumb != null;
        }
        prevKey = fromApp ? (prev != null ? prev.key() : null) : (cur != null ? cur.key() : null);
        int curIdx = cur != null ? list.indexOf(cur) : 0;
        int prevIdx = prevKey != null ? indexOf(list, prevKey) : curIdx;
        int focus = !fromApp ? curIdx : (Prefs.center(this) || prevIdx < 0 ? curIdx : prevIdx);
        // cards visible right away get their pictures before the first frame, so nothing loads on screen
        int wpx = thumbW();
        for (int k = Math.max(0, focus - 2); k <= Math.min(list.size() - 1, focus + 2); k++) {
            TaskItem t = list.get(k);
            if (t.taskId >= 0 && t.thumb == null) { android.graphics.Bitmap bm = Tasks.snapshot(t, false, wpx); if (bm != null) t.thumb = bm; }
        }
        deck.setItems(list, focus);
        deck.startEnter(fromApp && bigThumb, curIdx);
        updateBgChip();
        root.setAlpha(1f);
        for (View v : new View[]{back, closeAll, topBar, bgChip}) { v.setAlpha(0f); v.animate().alpha(1f).setDuration(bigThumb ? 420 : 260).setInterpolator(new android.view.animation.DecelerateInterpolator()).start(); }        loadThumbs(new ArrayList<>(list), focus);
        if (list.isEmpty() && !Tasks.shizukuReady() && !Tasks.usageAllowed(this)) {
            empty.setText("Нет доступа к списку приложений.\nОткройте «Недавние One UI» и выдайте доступ.");
        } else empty.setText("Нет недавних приложений");
    }

    private static int indexOf(List<TaskItem> l, String k) { for (int i = 0; i < l.size(); i++) if (l.get(i).key().equals(k)) return i; return -1; }

    private int thumbW() { return Math.round(getResources().getDisplayMetrics().widthPixels * 0.66f); }

    private void loadThumbs(List<TaskItem> list, int focus) {
        final int w = thumbW();
        List<TaskItem> ordered = new ArrayList<>();
        for (int d = 0; d < list.size(); d++) {
            int a = focus + d, b2 = focus - d;
            if (a >= 0 && a < list.size() && !ordered.contains(list.get(a))) ordered.add(list.get(a));
            if (b2 >= 0 && b2 < list.size() && !ordered.contains(list.get(b2))) ordered.add(list.get(b2));
        }
        for (TaskItem t : ordered) {
            if (t.taskId < 0 || t.thumb != null) continue; // a picture already on screen is never swapped
            io.execute(() -> {
                if (isFinishing()) return;
                android.graphics.Bitmap bm = Tasks.snapshot(t, false, w);
                if (bm != null) { t.thumb = bm; ui.post(deck::thumbArrived); }
            });
        }
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        String a = i.getAction();
        if (ACTION_TOGGLE.equals(a)) { deck.launch(deck.focusedIndex()); return; }
        if (ACTION_QUICK.equals(a)) {
            int k = prevKey != null ? deck.indexOfKey(prevKey) : -1;
            deck.launch(k >= 0 ? k : deck.focusedIndex());
            return;
        }        setIntent(i);
        open(i);
    }

    @Override protected void onResume() { super.onResume(); visible = true; }
    @Override protected void onPause() { super.onPause(); visible = false; }

    @Override protected void onStop() {
        super.onStop();
        if (popup != null) popup.dismiss();
        if (!isFinishing()) { finish(); overridePendingTransition(0, 0); }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        visible = false;
        io.shutdownNow();
        deck.clearShaders();
    }

    @Override public void onBackPressed() { if (sheet != null) { closeSheet(true); return; } leave(null); }

    private void leave(Runnable then) {
        if (leaving) return;
        leaving = true;
        deck.startExit(() -> {
            if (then != null) then.run();
            finish();
            overridePendingTransition(0, 0);
        });
        root.animate().alpha(0f).setDuration(160).start();
    }

    // ---------------------------------------------------------------- Host

    @Override public void onLaunch(TaskItem t, RectF r) {
        if (leaving) return;
        leaving = true;
        final boolean behind = t.key().equals(currentKey); // this app is right behind us
        for (View v : new View[]{closeAll, topBar}) v.animate().alpha(0f).setDuration(200).start();
        deck.expand(deck.indexOfKey(t.key()), () -> {
            if (behind) { finish(); overridePendingTransition(0, 0); return; }
            ActivityOptions o = ActivityOptions.makeCustomAnimation(this, R.anim.none, R.anim.none);
            if (!Tasks.launch(this, t, o.toBundle())) {
                Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show();
                finish(); overridePendingTransition(0, 0);
                return;
            }
            // our window stays until the app has drawn over it (onStop), so nothing flickers in between
            ui.postDelayed(() -> { if (!isFinishing()) { finish(); overridePendingTransition(0, 0); } }, 1500);
        });
    }
    @Override public void onHome() { goHome(); }

    private void goHome() {
        leave(() -> {
            Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(h); } catch (Throwable ignored) {}
        });
    }

    @Override public void onDismiss(TaskItem t) {
        all.remove(t);
        io.execute(() -> Tasks.remove(getApplicationContext(), t));
        // the last card was swiped away: nothing left to show
        if (deck.items().isEmpty() && bgList.isEmpty()) ui.postDelayed(this::goHome, 220);
    }

    @Override public void onLockToggle(TaskItem t) {
        t.locked = !t.locked;
        Prefs.setLocked(this, t.pkg, t.locked);
        for (TaskItem x : all) if (x.pkg.equals(t.pkg)) x.locked = t.locked;
        if (Tasks.isOplus() && t.locked) {
            List<TaskItem> same = new ArrayList<>();
            for (TaskItem x : deck.items()) if (x.pkg.equals(t.pkg)) same.add(x);
            for (TaskItem x : same) { if (!bgList.contains(x)) bgList.add(x); deck.hideItem(x); }
            updateBgChip();
        } else deck.invalidate();
    }

    private void updateBgChip() {
        boolean show = Tasks.isOplus() && !bgList.isEmpty();
        bgChip.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) return;
        bgChip.setText(bgList.size() + " в фоне");
        int lay = Prefs.layout(this);
        boolean flat = lay == Prefs.VERTICAL || lay == Prefs.SLIM;
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(22 * dp);
        d.setColor(night ? 0x571C1C1C : (flat ? 0x57737373 : 0x33FCFCFC));
        if (night || flat) d.setStroke(Math.max(1, Math.round(dp)), 0x4DFCFCFC);
        bgChip.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), d, null));
        bgChip.setTextColor(night ? 0xE6FAFAFA : 0xFFFAFAFA);
    }

    /** Bottom sheet with the apps kept in the background (locked). */
    private void openBgSheet() {
        if (sheet != null || bgList.isEmpty()) return;
        sheet = new FrameLayout(this);
        View scrim = new View(this);
        scrim.setBackgroundColor(0x66000000);
        scrim.setOnClickListener(v -> closeSheet(true));
        sheet.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setClickable(true);
        int pad = Math.round(24 * dp);
        panel.setPadding(pad, Math.round(12 * dp), pad, navBottom + Math.round(20 * dp));
        GradientDrawable pbg = new GradientDrawable();
        float r = 28 * dp;
        pbg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        pbg.setColor(night ? 0xFF242426 : 0xFFFCFCFC);
        panel.setBackground(pbg);
        View handle = new View(this);
        GradientDrawable hb = new GradientDrawable(); hb.setCornerRadius(2 * dp); hb.setColor(night ? 0xFF6E6E73 : 0xFFC7C7CC);
        handle.setBackground(hb);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(Math.round(40 * dp), Math.round(4 * dp));
        hl.gravity = Gravity.CENTER_HORIZONTAL; hl.bottomMargin = Math.round(18 * dp);
        panel.addView(handle, hl);
        TextView title = new TextView(this);
        title.setText("Работают в фоне");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
        title.setTextColor(night ? 0xFFF2F2F2 : 0xFF1C1C1E);
        panel.addView(title);
        TextView sub = new TextView(this);
        sub.setText("Приложения с замком не показываются в недавних и не закрываются кнопкой «Закрыть все».");
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        sub.setTextColor(night ? 0xFFA1A1A6 : 0xFF6E6E73);
        sub.setPadding(0, Math.round(4 * dp), 0, Math.round(10 * dp));
        panel.addView(sub);
        for (TaskItem t : new ArrayList<>(bgList)) panel.addView(bgRow(t, panel));
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        sheet.addView(panel, pl);
        root.addView(sheet, new FrameLayout.LayoutParams(-1, -1));
        scrim.setAlpha(0f);
        scrim.animate().alpha(1f).setDuration(220).start();
        panel.setTranslationY(getResources().getDisplayMetrics().heightPixels);
        panel.animate().translationY(0).setDuration(340).setInterpolator(new android.view.animation.PathInterpolator(0.2f, 0f, 0f, 1f)).start();
    }

    private View bgRow(final TaskItem t, final LinearLayout panel) {
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(Math.round(68 * dp));
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
        row.setBackgroundResource(tv.resourceId);
        ImageView ic = new ImageView(this);
        android.graphics.Bitmap rb = Prefs.round(this) ? Tasks.roundIcon(t, Math.round(56 * dp)) : null;
        if (rb != null) ic.setImageBitmap(rb); else ic.setImageDrawable(t.icon);
        row.addView(ic, new LinearLayout.LayoutParams(Math.round(44 * dp), Math.round(44 * dp)));
        TextView name = new TextView(this);
        name.setText(t.label);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        name.setTextColor(night ? 0xFFF2F2F2 : 0xFF1C1C1E);
        name.setPadding(Math.round(16 * dp), 0, Math.round(8 * dp), 0);
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        ImageView lock = new ImageView(this);
        lock.setImageResource(R.drawable.ic_lock);
        lock.setScaleType(ImageView.ScaleType.CENTER);
        GradientDrawable lb = new GradientDrawable(); lb.setShape(GradientDrawable.OVAL); lb.setColor(0xFF505050);
        lock.setBackground(lb);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(Math.round(40 * dp), Math.round(40 * dp));
        ll.rightMargin = Math.round(10 * dp);
        row.addView(lock, ll);
        TextView close = new TextView(this);
        close.setText("✕");
        close.setGravity(Gravity.CENTER);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        close.setTextColor(night ? 0xFFF2F2F2 : 0xFF3A3A3C);
        GradientDrawable cbg = new GradientDrawable(); cbg.setCornerRadius(20 * dp); cbg.setColor(night ? 0xFF3A3A3C : 0xFFE5E5EA);
        close.setBackground(cbg);
        row.addView(close, new LinearLayout.LayoutParams(Math.round(48 * dp), Math.round(40 * dp)));
        lock.setOnClickListener(v -> {           // take the lock off: the card goes back to recents
            t.locked = false;
            Prefs.setLocked(this, t.pkg, false);
            for (TaskItem x : all) if (x.pkg.equals(t.pkg)) x.locked = false;
            bgList.remove(t);
            List<TaskItem> vis = new ArrayList<>();
            for (TaskItem x : all) if (!x.locked && (deck.items().contains(x) || x == t)) vis.add(x);
            deck.setItemsAnimated(vis);
            removeRow(panel, row);
        });
        close.setOnClickListener(v -> {          // real close
            bgList.remove(t);
            all.remove(t);
            io.execute(() -> Tasks.remove(getApplicationContext(), t));
            removeRow(panel, row);
        });
        row.setOnClickListener(v -> {
            closeSheet(false);
            leaving = true;
            ActivityOptions o = ActivityOptions.makeCustomAnimation(this, R.anim.none, R.anim.none);
            if (!Tasks.launch(this, t, o.toBundle())) { leaving = false; Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show(); return; }
            ui.postDelayed(() -> { if (!isFinishing()) { finish(); overridePendingTransition(0, 0); } }, 1500);
        });
        return row;
    }

    private void removeRow(LinearLayout panel, View row) {
        row.animate().alpha(0f).setDuration(160).withEndAction(() -> {
            panel.removeView(row);
            updateBgChip();
            if (bgList.isEmpty()) closeSheet(true);
        }).start();
    }

    private void closeSheet(boolean anim) {
        if (sheet == null) return;
        final FrameLayout s = sheet;
        sheet = null;
        if (!anim) { root.removeView(s); return; }
        View panel = s.getChildAt(1);
        s.getChildAt(0).animate().alpha(0f).setDuration(200).start();
        panel.animate().translationY(panel.getHeight()).setDuration(240).withEndAction(() -> root.removeView(s)).start();
    }

    @Override public void onCountChanged(int n) {
        empty.setVisibility(n == 0 ? View.VISIBLE : View.GONE);
        closeAll.setVisibility(n == 0 ? View.GONE : View.VISIBLE);
    }

    @Override public void onMenu(TaskItem t, RectF anchor) {
        List<String> names = new ArrayList<>();
        List<Runnable> acts = new ArrayList<>();
        names.add("Сведения о приложении");
        acts.add(() -> leave(() -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + t.pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(i); } catch (Throwable ignored) {}
        }));
        names.add(t.locked ? "Разрешить закрытие" : "Не закрывать");
        acts.add(() -> onLockToggle(t));
        names.add("Закрыть");
        acts.add(() -> deck.removeItem(t));
        showPopup(names, acts, anchor);
    }

    private void openMore(View v) {
        List<String> names = new ArrayList<>();
        List<Runnable> acts = new ArrayList<>();
        names.add("Настройки");
        acts.add(() -> leave(() -> startActivity(new Intent(this, SettingsActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))));
        int[] loc = new int[2];
        v.getLocationInWindow(loc);
        showPopup(names, acts, new RectF(loc[0], loc[1], loc[0] + v.getWidth(), loc[1] + v.getHeight()));
    }

    private void showPopup(List<String> names, List<Runnable> acts, RectF anchor) {
        if (popup != null) popup.dismiss();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pv = Math.round(6 * dp);
        box.setPadding(0, pv, 0, pv);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(26 * dp);
        bg.setColor(night ? 0xFF2C2C2E : 0xFFFCFCFC);
        box.setBackground(bg);
        box.setClipToOutline(true);
        final PopupWindow pw = new PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        for (int k = 0; k < names.size(); k++) {
            TextView tv = new TextView(this);
            tv.setText(names.get(k));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            tv.setTextColor(night ? 0xFFF2F2F2 : 0xFF1C1C1E);
            tv.setMinWidth(Math.round(180 * dp));
            tv.setMinHeight(Math.round(48 * dp));
            tv.setGravity(Gravity.CENTER_VERTICAL);
            tv.setPadding(Math.round(24 * dp), 0, Math.round(24 * dp), 0);
            TypedValue t = new TypedValue();
            getTheme().resolveAttribute(android.R.attr.selectableItemBackground, t, true);
            tv.setBackgroundResource(t.resourceId);
            final Runnable r = acts.get(k);
            tv.setOnClickListener(x -> { pw.dismiss(); r.run(); });
            box.addView(tv);
        }
        pw.setElevation(8 * dp);
        pw.setBackgroundDrawable(new ColorDrawable(0));
        pw.setOutsideTouchable(true);
        box.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int w = box.getMeasuredWidth(), h = box.getMeasuredHeight();
        int sw = root.getWidth(), sh = root.getHeight();
        int x = Math.round(anchor.centerX() - w / 2f);
        x = Math.max(Math.round(12 * dp), Math.min(x, sw - w - Math.round(12 * dp)));
        int y = Math.round(anchor.bottom + 6 * dp);
        if (y + h > sh - 12 * dp) y = Math.round(anchor.top - h - 6 * dp);
        pw.showAtLocation(root, Gravity.TOP | Gravity.START, x, Math.max(0, y));
        popup = pw;
    }

    private void openSearch() {
        Intent[] tries = {
                new Intent("android.search.action.GLOBAL_SEARCH"),
                new Intent(Intent.ACTION_WEB_SEARCH),
                new Intent(Intent.ACTION_ASSIST)
        };
        for (Intent i : tries) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (i.resolveActivity(getPackageManager()) != null) {
                leave(() -> { try { startActivity(i); } catch (Throwable ignored) {} });
                return;
            }
        }
        Toast.makeText(this, "Поиск не найден", Toast.LENGTH_SHORT).show();
    }
}
