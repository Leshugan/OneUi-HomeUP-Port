package leshugan.recents;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;

/**
 * Lays an invisible touch pad over the system «Recents» button of the 3-button navigation bar.
 * Tap opens the One UI recents, a quick second tap switches to the previous app,
 * a long press keeps the system split-screen action.
 */
public final class NavService extends AccessibilityService implements SharedPreferences.OnSharedPreferenceChangeListener {
    static final String TAG = "OneUIRecents";

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View pad;
    private final Rect padRect = new Rect();
    private String fgPkg;
    private long lastTap;
    private final Runnable update = this::updatePad;
    private final java.util.concurrent.ExecutorService warm = java.util.concurrent.Executors.newSingleThreadExecutor();
    /** Keeps pictures of recent apps ready, so the recents screen never shows them loading. */
    private final Runnable prewarm = () -> warm.execute(() -> {
        try {
            if (!Tasks.shizukuReady()) return;
            int w = Math.round(getResources().getDisplayMetrics().widthPixels * 0.66f);
            for (TaskItem t : Tasks.load(this)) {
                if (t.recency == 0 || t.recency > 6) continue;
                if (t.recency == 1 || Tasks.THUMBS.get(t.key()) == null) Tasks.snapshot(t, false, w);
            }
        } catch (Throwable ignored) {}
    });

    @Override protected void onServiceConnected() {
        wm = getSystemService(WindowManager.class);
        Tasks.ensureBinder(this);
        new Thread(() -> Wallpaper.load(this)).start();
        try {
            registerReceiver(new android.content.BroadcastReceiver() {
                @Override public void onReceive(android.content.Context c, Intent i) { new Thread(() -> Wallpaper.load(c)).start(); }
            }, new android.content.IntentFilter(Intent.ACTION_WALLPAPER_CHANGED));
        } catch (Throwable ignored) {}
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(this);
        h.postDelayed(update, 300);
    }

    @Override public void onDestroy() {
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(this);
        removePad();
        super.onDestroy();
    }

    @Override public boolean onUnbind(Intent i) { removePad(); return super.onUnbind(i); }

    @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        if (Prefs.ENABLED.equals(key)) { h.removeCallbacks(update); h.post(update); }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName() != null) {
            String p = e.getPackageName().toString();
            CharSequence cn = e.getClassName();
            if (!p.equals(getPackageName()) && !p.equals("com.android.systemui") && cn != null) {
                String c = cn.toString();
                if (!c.startsWith("android.widget") && !c.startsWith("android.view") && !c.contains("Dialog")
                        && !c.contains("InputMethod") && !c.contains("Toast")) {
                    if (!p.equals(fgPkg)) { h.removeCallbacks(prewarm); h.postDelayed(prewarm, 700); }
                    fgPkg = p;
                }
            }
        }
        h.removeCallbacks(update);
        h.postDelayed(update, 120);
    }

    @Override public void onInterrupt() {}

    @Override protected boolean onKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.KEYCODE_APP_SWITCH && Prefs.enabled(this)) {
            if (e.getAction() == KeyEvent.ACTION_UP) onRecentsTap();
            return true;
        }
        return false;
    }

    private void updatePad() {
        if (!Prefs.enabled(this)) { removePad(); return; }
        Rect r = findRecentsButton();
        if (r == null) { removePad(); return; }
        if (pad != null && r.equals(padRect)) return;
        padRect.set(r);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(r.width(), r.height(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = r.left; lp.y = r.top;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("OneUIRecentsPad");
        try {
            if (pad == null) {
                pad = makePad();
                wm.addView(pad, lp);
            } else wm.updateViewLayout(pad, lp);
            Log.i(TAG, "pad at " + r);
        } catch (Throwable t) { Log.w(TAG, "pad failed", t); pad = null; padRect.setEmpty(); }
    }

    private void removePad() {
        if (pad != null) { try { wm.removeView(pad); } catch (Throwable ignored) {} pad = null; }
        padRect.setEmpty();
    }

    private View makePad() {
        View v = new View(this);
        v.setHapticFeedbackEnabled(true);
        final Runnable[] lp = new Runnable[1];
        final boolean[] longDone = new boolean[1];
        v.setOnTouchListener((view, ev) -> {
            if (DEBUG) Log.e(TAG, "pad touch " + ev.getActionMasked());
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    longDone[0] = false;
                    lp[0] = () -> {
                        longDone[0] = true;
                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                        performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN);
                    };
                    view.postDelayed(lp[0], ViewConfiguration.getLongPressTimeout());
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    return true;
                case MotionEvent.ACTION_UP:
                    view.removeCallbacks(lp[0]);
                    if (!longDone[0]) onRecentsTap();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    view.removeCallbacks(lp[0]);
                    return true;
            }
            return true;
        });
        return v;
    }

    void onRecentsTap() {
        long now = SystemClock.uptimeMillis();
        boolean quick = now - lastTap < 400;
        lastTap = now;
        Intent i = new Intent(this, RecentsActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        if (RecentsActivity.visible) i.setAction(quick ? RecentsActivity.ACTION_QUICK : RecentsActivity.ACTION_TOGGLE);
        else {
            i.setAction(RecentsActivity.ACTION_SHOW);
            if (fgPkg != null) i.putExtra(RecentsActivity.EXTRA_FG, fgPkg);
            i.putExtra(RecentsActivity.EXTRA_HOME, fgPkg != null && isHome(fgPkg));
        }
        if (DEBUG) Log.e(TAG, "open " + i.getAction() + " fg=" + fgPkg);
        try { startActivity(i); } catch (Throwable t) { Log.e(TAG, "start failed", t); }
    }

    private java.util.Set<String> homes;

    private boolean isHome(String p) {
        if (homes == null) {
            homes = new java.util.HashSet<>();
            Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            for (android.content.pm.ResolveInfo r : getPackageManager().queryIntentActivities(h, android.content.pm.PackageManager.MATCH_ALL)) homes.add(r.activityInfo.packageName);
        }
        return homes.contains(p);
    }

    /** Finds the «Recents» button of the navigation bar on screen. */
    private Rect findRecentsButton() {
        List<AccessibilityWindowInfo> ws;
        try { ws = getWindows(); } catch (Throwable t) { return null; }
        int sw = getResources().getDisplayMetrics().widthPixels, sh = getResources().getDisplayMetrics().heightPixels;
        for (AccessibilityWindowInfo w : ws) {
            AccessibilityNodeInfo root = w.getRoot();
            if (DEBUG) Log.e(TAG, "window type=" + w.getType() + " title=" + w.getTitle() + " root=" + (root == null ? null : root.getPackageName()));
            if (root == null) continue;
            CharSequence pk = root.getPackageName();
            if (pk == null || !"com.android.systemui".contentEquals(pk)) continue;
            Rect wb = new Rect();
            w.getBoundsInScreen(wb);
            if (DEBUG) { StringBuilder sb = new StringBuilder(); dump(root, 0, sb); Log.i(TAG, "win type=" + w.getType() + " " + wb + " title=" + w.getTitle() + "\n" + sb); }
            if (wb.height() > sh / 3 && wb.width() > sw / 3) continue; // not the navigation bar
            AccessibilityNodeInfo n = null;
            List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId("com.android.systemui:id/recent_apps");
            if (l != null) for (AccessibilityNodeInfo x : l) if (x.isVisibleToUser()) { n = x; break; }
            if (n == null) n = byDesc(root, 0);
            if (n != null) {
                Rect r = new Rect();
                AccessibilityNodeInfo par = n.getParent();
                if (par != null) par.getBoundsInScreen(r); else n.getBoundsInScreen(r);
                if (r.width() > sw / 2 || r.width() <= 0) n.getBoundsInScreen(r);
                if (r.width() > 0 && r.height() > 0) return r;
            }
        }
        return null;
    }

    static boolean DEBUG = false;

    private void dump(AccessibilityNodeInfo n, int d, StringBuilder sb) {
        if (n == null || d > 8 || sb.length() > 3000) return;
        Rect r = new Rect(); n.getBoundsInScreen(r);
        sb.append(d).append(' ').append(n.getViewIdResourceName()).append(" desc=").append(n.getContentDescription())
                .append(" cls=").append(n.getClassName()).append(' ').append(r).append(" vis=").append(n.isVisibleToUser()).append('\n');
        for (int i = 0; i < n.getChildCount(); i++) dump(n.getChild(i), d + 1, sb);
    }

    private AccessibilityNodeInfo byDesc(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 12) return null;
        CharSequence d = n.getContentDescription();
        if (d != null && n.isVisibleToUser()) {
            String s = d.toString().toLowerCase();
            if (s.equals("обзор") || s.contains("недавн") || s.contains("recent") || s.equals("overview")) return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = byDesc(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }
}
