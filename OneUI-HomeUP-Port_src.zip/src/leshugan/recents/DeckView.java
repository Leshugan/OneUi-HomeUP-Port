package leshugan.recents;

import android.animation.AnimatorListenerAdapter;
import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.OverScroller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Draws the recent apps in the five One UI layouts (List, Grid, Vertical list, Slim list, Tilt stack)
 * and handles scrolling, swipe-to-close, taps and the open animation. Proportions are taken from
 * One UI Home resources (task_scene_scale_*, task_scene_top_*, page_spacing_*, tilt_stack intervals).
 */
public final class DeckView extends View {

    public interface Host {
        void onLaunch(TaskItem t, RectF cardOnScreen);
        void onHome();
        void onMenu(TaskItem t, RectF anchor);
        void onDismiss(TaskItem t);
        void onCountChanged(int n);
        void onLockToggle(TaskItem t);
    }

    /** Geometry of one card for one frame. */
    static final class G {
        float cx, cy, w, h, scale = 1, rot, alpha = 1, radius;
        float iconCx, iconCy, iconSize, iconAlpha = 1;
        boolean labelRight;
        float labelX, labelY; int labelColor = Color.WHITE; float labelSize;
        float order;
        boolean pill, topCrop;
        RectF rect(RectF r) {
            float hw = w * scale / 2, hh = h * scale / 2;
            r.set(cx - hw, cy - hh, cx + hw, cy + hh);
            return r;
        }
    }

    private final Host host;
    private final float dp;
    private final List<TaskItem> items = new ArrayList<>();
    private int layout = Prefs.TILT;
    private boolean mini, label, circular, night, iconBar, roundIcons;
    private boolean stripTouch;
    private int topInset, bottomInset;
    private float W, H;

    private float pos, step = 1, maxPos;
    private int pendingFocus = -1;
    private final OverScroller scroller;
    private ValueAnimator posAnim;

    private float downX, downY, lastX, lastY, dragStartP;
    private int mode; // 0 none, 1 scroll, 2 dismiss
    private int dragIndex = -1;
    private float dragOff;
    private VelocityTracker vt;
    private final int slop, minFling;
    private boolean longPressed;
    private final Runnable longPress = this::onLongPress;
    private int downHit = -1;

    private float enterT = 1f;
    private boolean enterFromApp;
    private int enterIndex;
    private int expandIndex = -1;
    private float expandT;
    private float exitT = 0f;
    private final HashMap<String, G> from = new HashMap<>();
    private float morphT = 1f;
    private final HashMap<String, float[]> flyOff = new HashMap<>();

    private final Paint cardP = Tasks.aa(), strokeP = Tasks.aa(), textP = Tasks.aa(), pillP = Tasks.aa(), badgeP = Tasks.aa();
    private final Matrix mtx = new Matrix();
    private final RectF tmp = new RectF();
    private final HashMap<Bitmap, BitmapShader> shaders = new HashMap<>();
    private final Drawable lockIcon, lockOpenIcon;

    public DeckView(Context c, Host host) {
        super(c);
        this.host = host;
        dp = getResources().getDisplayMetrics().density;
        scroller = new OverScroller(c, new DecelerateInterpolator(1.6f));
        ViewConfiguration vc = ViewConfiguration.get(c);
        slop = vc.getScaledTouchSlop();
        minFling = vc.getScaledMinimumFlingVelocity();
        strokeP.setStyle(Paint.Style.STROKE);
        strokeP.setStrokeWidth(Math.max(1f, 0.5f * dp));
        textP.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        lockIcon = c.getDrawable(R.drawable.ic_lock);
        lockOpenIcon = c.getDrawable(R.drawable.ic_lock_open);
        setHapticFeedbackEnabled(true);
    }

    // ---------------------------------------------------------------- setup

    public void setInsets(int top, int bottom) { topInset = top; bottomInset = bottom; computeGeo(); invalidate(); }

    public void setItems(List<TaskItem> list, int focus) {
        items.clear();
        items.addAll(list);
        pendingFocus = snaps() ? Math.min(focus, Math.max(0, items.size() - 1)) : 0;
        computeGeo();
        if (W > 0) { pos = pendingFocus * step; pendingFocus = -1; clampPos(); }
        host.onCountChanged(items.size());
        invalidate();
    }

    public void applyPrefs() {
        Context c = getContext();
        layout = Prefs.layout(c);
        mini = Prefs.mini(c) && (layout == Prefs.LIST || layout == Prefs.GRID || layout == Prefs.TILT);
        label = Prefs.label(c);
        circular = Prefs.circular(c);
        roundIcons = Prefs.round(c);
        iconBar = Prefs.iconBar(c) && (layout == Prefs.LIST || layout == Prefs.TILT);
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        computeGeo();
        invalidate();
    }

    public List<TaskItem> items() { return items; }

    private boolean snaps() { return layout == Prefs.LIST || layout == Prefs.TILT; }

    public int focusedIndex() {
        if (items.isEmpty()) return -1;
        if (snaps()) return Math.round(clamp(pos / step, 0, items.size() - 1));
        return 0;
    }

    public void thumbArrived() { postInvalidateOnAnimation(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float f = snaps() && step > 0 ? pos / step : -1;
        W = w; H = h;
        computeGeo();
        if (pendingFocus >= 0) { pos = snaps() ? pendingFocus * step : 0; pendingFocus = -1; clampPos(); }
        else if (f >= 0) { pos = f * step; clampPos(); }
    }

    private boolean horizontal() { return layout == Prefs.LIST || layout == Prefs.GRID || layout == Prefs.TILT; }

    private float bottomReserve() { return bottomInset + 31 * dp + 44 * dp + 20 * dp + (iconBar ? 72 * dp : 0); }

    // ---- OnePlus-style row of app icons under the cards: drag it to run through the apps quickly
    private float stripY() { return H - bottomInset - 31 * dp - 44 * dp - 40 * dp; }
    private float stripGap() { return 54 * dp; }

    private void computeGeo() {
        if (W == 0) return;
        int n = items.size();
        switch (layout) {
            case Prefs.LIST: step = cardW() + 0.056f * W; maxPos = Math.max(0, n - 1) * step; break;
            case Prefs.TILT: step = 0.6f * W; maxPos = Math.max(0, n - 1) * step; break;
            case Prefs.GRID: {
                float cw = cardW(), gap = 0.04f * W;
                step = cw + gap;
                int cols = (n + 1) / 2;
                maxPos = Math.max(0, cols * step - gap - (0.91f * W - 0.09f * W));
                break;
            }
            default: {
                float ch = layout == Prefs.VERTICAL ? 0.206f * H : 0.077f * H;
                float gap = layout == Prefs.VERTICAL ? 0.026f * H : 0.018f * H;
                step = ch + gap;
                float focusTop = layout == Prefs.VERTICAL ? 0.593f * H : 0.677f * H;
                float topLimit = topInset + 64 * dp;
                maxPos = Math.max(0, (n - 1) * step - (focusTop - topLimit));
                break;
            }
        }
        clampPos();
    }

    private float m() { return mini ? 0.5f : 1f; }

    private float cardW() {
        switch (layout) {
            case Prefs.LIST: return 0.6f * W * m();
            case Prefs.GRID: return 0.29f * W * m();
            case Prefs.TILT: return 0.631f * W * m();
            case Prefs.VERTICAL: return 0.542f * W;
            default: return 0.9f * W;
        }
    }

    private float cardH() {
        switch (layout) {
            case Prefs.LIST: return 0.6f * H * m();
            case Prefs.GRID: return 0.29f * H * m();
            case Prefs.TILT: return 0.631f * H * m();
            case Prefs.VERTICAL: return 0.206f * H;
            default: return 0.077f * H;
        }
    }

    private void clampPos() { pos = clamp(pos, 0, maxPos); }

    static float clamp(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
    static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    // ---------------------------------------------------------------- layouts

    private void geo(int i, G o) {
        o.scale = 1; o.rot = 0; o.alpha = 1; o.iconAlpha = 1; o.pill = false; o.topCrop = false;
        o.labelRight = false; o.labelColor = Color.WHITE;
        float cw = cardW(), ch = cardH();
        o.w = cw; o.h = ch;
        boolean lab = label;
        switch (layout) {
            case Prefs.LIST: {
                float top = mini ? H - bottomReserve() - ch - 12 * dp : 0.145f * H;
                float d = pos / step - i;
                float ad = Math.min(Math.abs(d), 1f);
                o.scale = 1f - 0.135f * ad;
                o.cx = W / 2f + d * step - Math.signum(d) * (1f - o.scale) * cw / 2f;
                o.cy = top + ch / 2f;
                o.radius = 15 * dp * m() + 5 * dp;
                o.iconSize = (lab ? 26 : 44) * dp * (mini ? 0.75f : 1f);
                o.iconCx = o.cx;
                o.iconCy = o.cy - ch * o.scale / 2f - 10 * dp - o.iconSize / 2f;
                o.labelRight = lab; o.labelSize = 14 * dp;
                o.order = -Math.abs(d);
                break;
            }
            case Prefs.GRID: {
                float rowGap = 0.06f * H * m();
                int col = i / 2, row = i % 2;
                float top = mini ? H - bottomReserve() - (2 * ch + rowGap) - 12 * dp : 0.11f * H + 22 * dp;
                float right = 0.91f * W - col * step + pos;
                o.cx = right - cw / 2f;
                o.cy = top + row * (ch + rowGap) + ch / 2f;
                o.radius = 13 * dp * m() + 3 * dp;
                o.iconSize = (lab ? 22 : 36) * dp * (mini ? 0.75f : 1f);
                o.iconCx = o.cx;
                o.iconCy = o.cy - ch / 2f - (lab ? 8 * dp + o.iconSize / 2f : 0);
                o.labelRight = lab; o.labelSize = 13 * dp;
                o.order = i;
                break;
            }
            case Prefs.VERTICAL: {
                float top = 0.593f * H - i * step + pos;
                float baseCx = 0.367f * W + cw / 2f;
                o.cx = baseCx;
                o.cy = top + ch / 2f;
                if (circular) {
                    float dist = (o.cy - 0.5f * H) / (0.5f * H);
                    float k = Math.min(dist * dist, 1.5f);
                    o.cx += 0.25f * W * k * 0.55f;
                    o.scale = 1f - 0.12f * Math.min(k, 1f);
                }
                o.topCrop = true;
                o.radius = 30 * dp;
                o.iconSize = 26 * dp;
                o.iconCx = 0.06f * W + o.iconSize / 2f + (o.cx - baseCx);
                o.iconCy = o.cy - ch * o.scale / 2f + o.iconSize / 2f + 4 * dp;
                o.labelRight = true; o.labelSize = 13 * dp;
                float topLimit = topInset + 56 * dp;
                float cardTop = o.cy - ch * o.scale / 2f;
                if (cardTop < topLimit) o.alpha = clamp(1f - (topLimit - cardTop) / (ch * 0.8f), 0, 1);
                o.order = i;
                break;
            }
            case Prefs.SLIM: {
                float top = 0.677f * H - i * step + pos;
                o.cx = W / 2f;
                o.cy = top + ch / 2f;
                o.pill = true;
                o.radius = ch / 2f;
                o.iconSize = 30 * dp;
                o.iconCx = o.cx - cw / 2f + 20 * dp + o.iconSize / 2f;
                o.iconCy = o.cy;
                o.labelRight = true; o.labelSize = 14 * dp;
                o.labelColor = night ? Color.WHITE : 0xFF1C1C1E;
                float topLimit = topInset + 56 * dp;
                float cardTop = o.cy - ch / 2f;
                if (cardTop < topLimit) o.alpha = clamp(1f - (topLimit - cardTop) / (ch * 1.5f), 0, 1);
                o.order = i;
                break;
            }
            default: { // TILT
                float iconSz = (lab ? 26 : 44) * dp * (mini ? 0.75f : 1f);
                float top = mini ? H - bottomReserve() - ch - 12 * dp : 0.114f * H + iconSz / 2f;
                float cl = (W - cw) / 2f;
                float d = i - pos / step;
                float[] kd = {-2, -1, 0, 1, 2, 3};
                float[] kl = {cl + 2 * (cw + 0.044f * W), cl + cw + 0.044f * W, cl, cl - 0.144f * W, cl - 0.278f * W, cl - 0.35f * W};
                float[] ks = {1.05f, 1.05f, 1f, 0.9f, 0.8f, 0.7f};
                float[] kr = {0, 0, 0, -4f, -2.4f, 0};
                float[] ka = {1, 1, 1, 1, 1, 0};
                float dc = clamp(d, -2, 3);
                int k = 0;
                while (k < kd.length - 2 && dc > kd[k + 1]) k++;
                float t = (dc - kd[k]) / (kd[k + 1] - kd[k]);
                float left = lerp(kl[k], kl[k + 1], t);
                o.scale = lerp(ks[k], ks[k + 1], t);
                o.rot = lerp(kr[k], kr[k + 1], t);
                o.alpha = lerp(ka[k], ka[k + 1], t);
                if (d < -2) left += (-2 - d) * (cw + 0.044f * W);
                o.cx = left + cw * o.scale / 2f;
                o.cy = top + ch / 2f;
                o.radius = 20 * dp * m() + 4 * dp;
                o.iconSize = iconSz;
                o.iconCx = o.cx;
                o.iconCy = o.cy - ch * o.scale / 2f - (lab ? 10 * dp + iconSz / 2f : 0);
                o.iconAlpha = clamp(1f - Math.abs(d) * 1.6f, 0, 1);
                o.labelRight = lab; o.labelSize = 14 * dp;
                o.order = -d;
                break;
            }
        }
        if (o.labelRight && !o.pill && layout != Prefs.VERTICAL) {
            String s = items.get(i).label;
            textP.setTextSize(o.labelSize);
            float tw = Math.min(textP.measureText(s == null ? "" : s), o.w * o.scale - o.iconSize - 6 * dp);
            float rowW = o.iconSize + 6 * dp + tw;
            o.iconCx = o.cx - rowW / 2f + o.iconSize / 2f;
        }
        o.labelX = o.iconCx + o.iconSize / 2f + (o.pill ? 15 : 6) * dp;
        o.labelY = o.iconCy + o.labelSize * 0.36f;
    }

    /** Final geometry including drag, close, open and morph animations. */
    private void finalGeo(int i, G o) {
        TaskItem t = items.get(i);
        geo(i, o);
        if (morphT < 1f) {
            G f = from.get(t.key());
            if (f != null) {
                float e = ease(morphT);
                o.cx = lerp(f.cx, o.cx, e); o.cy = lerp(f.cy, o.cy, e); o.scale = lerp(f.scale, o.scale, e);
                o.rot = lerp(f.rot, o.rot, e); o.alpha = lerp(f.alpha, o.alpha, e);
                o.w = lerp(f.w, o.w, e); o.h = lerp(f.h, o.h, e); o.radius = lerp(f.radius, o.radius, e);
                o.iconSize = lerp(f.iconSize, o.iconSize, e);
                o.iconCx = lerp(f.iconCx, o.iconCx, e); o.iconCy = lerp(f.iconCy, o.iconCy, e);
                o.labelX = lerp(f.labelX, o.labelX, e); o.labelY = lerp(f.labelY, o.labelY, e);
                o.iconAlpha = lerp(f.iconAlpha, o.iconAlpha, e);
            }
        }
        float[] fo = flyOff.get(t.key());
        float off = (i == dragIndex) ? dragOff : 0;
        float a = 1;
        if (fo != null) { off = fo[0]; a = fo[1]; }
        if (off != 0) {
            if (horizontal()) {
                o.cy += off; o.iconCy += off; o.labelY += off;
                a *= clamp(1f - Math.max(0, -off) / (o.h * o.scale * 1.1f), 0.2f, 1f);
            } else {
                o.cx += off; o.iconCx += off; o.labelX += off;
                a *= clamp(1f - Math.abs(off) / (o.w * 0.9f), 0.2f, 1f);
            }
        }
        o.alpha *= a;
        if (enterT < 1f) {
            float e = ease(enterT);
            if (enterFromApp && i == enterIndex && t.thumb != null) {
                float tw = o.w * o.scale, th = o.h * o.scale;
                float cw = lerp(W, tw, e), chh = lerp(H, th, e);
                o.cx = lerp(W / 2f, o.cx, e); o.cy = lerp(H / 2f, o.cy, e);
                o.w = cw / o.scale; o.h = chh / o.scale;
                o.rot *= e;
                o.radius = lerp(40 * dp, o.radius, e);
                o.iconAlpha *= e;
                o.topCrop = false;
            } else if (enterFromApp) {
                // neighbours are already there and slide in together with the shrinking app (no fade-in)
                float push = (1 - e) * 0.55f;
                float dx = (o.cx - W / 2f) * push, dy = horizontal() ? 0 : (o.cy - H / 2f) * push;
                o.cx += dx; o.iconCx += dx; o.labelX += dx;
                o.cy += dy; o.iconCy += dy; o.labelY += dy;
                o.alpha *= clamp(enterT * 6f, 0, 1);
                o.iconAlpha *= e;
            } else {
                o.alpha *= clamp(enterT * 1.4f - 0.15f, 0, 1);
                o.scale *= 1f + 0.06f * (1 - e);
                o.iconAlpha *= e;
            }
        }
        if (exitT > 0f) {
            o.alpha *= 1f - exitT;
            o.scale *= 1f + 0.04f * exitT;
        }
        if (expandIndex >= 0) {
            float e = expandT;
            if (i == expandIndex) {
                float sw = o.w * o.scale, sh = o.h * o.scale;
                o.w = lerp(sw, W, e); o.h = lerp(sh, H, e); o.scale = 1;
                o.cx = lerp(o.cx, W / 2f, e); o.cy = lerp(o.cy, H / 2f, e);
                o.rot = lerp(o.rot, 0, e);
                o.radius = lerp(o.radius, 0, e);
                if (o.pill && t.thumb != null) { o.pill = false; o.topCrop = true; }
                o.alpha = 1;
                o.iconAlpha *= 1f - e;
                o.order = 1e6f;
            } else {
                o.alpha *= 1f - e;
            }
        }
    }

    private static final PathInterpolator EASE = new PathInterpolator(0.22f, 0.25f, 0f, 1f);
    static float ease(float t) { return EASE.getInterpolation(clamp(t, 0, 1)); }

    // ---------------------------------------------------------------- drawing

    private final ArrayList<Integer> order = new ArrayList<>();
    private G[] cache = new G[0];

    private void buildFrame() {
        int n = items.size();
        if (cache.length < n) {
            G[] c = new G[n];
            for (int i = 0; i < n; i++) c[i] = i < cache.length ? cache[i] : new G();
            cache = c;
        }
        order.clear();
        for (int i = 0; i < n; i++) { finalGeo(i, cache[i]); order.add(i); }
        order.sort((a, b) -> Float.compare(cache[a].order, cache[b].order));
    }

    @Override protected void onDraw(Canvas c) {
        if (W == 0) return;
        boolean anim = enterT < 1f || morphT < 1f || (exitT > 0f && exitT < 1f) || (expandIndex >= 0 && expandT < 1f);
        if (!scroller.isFinished() && scroller.computeScrollOffset()) {
            pos = clamp(horizontal() ? scroller.getCurrX() : scroller.getCurrY(), 0, maxPos);
            anim = true;
        }
        buildFrame();
        for (int idx : order) {
            G o = cache[idx];
            if (o.alpha <= 0.01f) continue;
            o.rect(tmp);
            if (tmp.right < -W * 0.2f || tmp.left > W * 1.2f || tmp.bottom < -H * 0.2f || tmp.top > H * 1.2f) continue;
            drawCard(c, items.get(idx), o);
        }
        if (iconBar) drawStrip(c);
        if (anim) postInvalidateOnAnimation();
    }

    private void drawCard(Canvas c, TaskItem t, G o) {
        int alpha = Math.round(255 * clamp(o.alpha, 0, 1));
        float w = o.w, h = o.h;
        c.save();
        c.translate(o.cx, o.cy);
        if (o.rot != 0) c.rotate(o.rot);
        c.scale(o.scale, o.scale);
        tmp.set(-w / 2f, -h / 2f, w / 2f, h / 2f);
        float r = Math.min(o.radius, Math.min(w, h) / 2f);
        if (o.pill) {
            int col = night ? 0xD93A3A3C : 0xE6F4F4F6;
            pillP.setColor(col);
            pillP.setAlpha(Math.round(alpha * (col >>> 24) / 255f));
            c.drawRoundRect(tmp, r, r, pillP);
        } else {
            Bitmap b = t.thumb;
            boolean pic = b != null && !b.isRecycled();
            cardP.setShader(null);
            if (!pic) {
                cardP.setColor(night ? darken(t.color) : t.color);
                cardP.setAlpha(alpha);
                c.drawRoundRect(tmp, r, r, cardP);
            }
            if (pic) {
                BitmapShader sh = shaders.get(b);
                if (sh == null) { sh = new BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP); shaders.put(b, sh); }
                float s = w / b.getWidth();
                if (!o.topCrop) s = Math.max(s, h / b.getHeight());
                mtx.setScale(s, s);
                float ox = -w / 2f + (w - b.getWidth() * s) / 2f;
                float oy = o.topCrop ? -h / 2f : -h / 2f + (h - b.getHeight() * s) / 2f;
                mtx.postTranslate(ox, oy);
                sh.setLocalMatrix(mtx);
                cardP.setShader(sh);
                cardP.setAlpha(alpha);
                c.drawRoundRect(tmp, r, r, cardP);
                cardP.setShader(null);
            } else {
                drawAppIcon(c, t, 0, 0, Math.min(w, h) * 0.28f, alpha);
            }
            if (!pic && !night) {
                strokeP.setColor(0x1F000000);
                strokeP.setAlpha(Math.round(alpha * 0.12f));
                c.drawRoundRect(tmp, r, r, strokeP);
            }
        }
        drawLock(c, t, o, alpha);
        c.restore();

        int ia = Math.round(255 * clamp(o.alpha * o.iconAlpha, 0, 1));
        if (ia > 2) {
            drawAppIcon(c, t, o.iconCx, o.iconCy, o.iconSize, ia);
            if (o.labelRight) {
                textP.setTextSize(o.labelSize);
                textP.setColor(o.labelColor);
                textP.setAlpha(ia);
                if (o.pill) textP.clearShadowLayer(); else textP.setShadowLayer(3 * dp, 0, 1 * dp, 0x66000000);
                float maxW = o.pill ? o.w - (o.labelX - (o.cx - o.w / 2f)) - 16 * dp
                        : layout == Prefs.VERTICAL ? (o.cx - o.w * o.scale / 2f) - o.labelX - 6 * dp
                        : o.w * o.scale - o.iconSize - 6 * dp;
                c.drawText(ellipsize(t.label, maxW), o.labelX, o.labelY, textP);
            }
        }
    }

    /** Lock button position inside the card (card units, before scale): x, y, radius. Like One UI task_lock (56 dp). */
    private float[] lockLocal(G o) {
        float R = Math.min(28 * dp, Math.max(17 * dp, o.w * o.scale * 0.085f));
        if (o.pill) R = Math.min(R, o.h * o.scale * 0.36f);
        float rl = R / o.scale, m = (o.pill ? 14 : 12) * dp / o.scale;
        return new float[]{o.w / 2f - m - rl, o.pill ? 0 : o.h / 2f - m - rl, rl};
    }

    private void drawLock(Canvas c, TaskItem t, G o, int alpha) {
        if (!t.locked) return; // the lock is set from the app icon menu; only a locked card shows it
        int a = Math.round(alpha * clamp(o.iconAlpha, 0, 1));
        if (a < 8) return;
        float[] l = lockLocal(o);
        if (t.locked) {
            badgeP.setStyle(Paint.Style.FILL);
            badgeP.setColor(0xFF505050);
            badgeP.setAlpha(a);
            c.drawCircle(l[0], l[1], l[2], badgeP);
        } else {
            badgeP.setStyle(Paint.Style.FILL);
            badgeP.setColor(0x66282828);
            badgeP.setAlpha(Math.round(a * 0.4f));
            c.drawCircle(l[0], l[1], l[2], badgeP);
            badgeP.setStyle(Paint.Style.STROKE);
            badgeP.setStrokeWidth(Math.max(1f, dp) / o.scale);
            badgeP.setColor(0xFFFAFAFA);
            badgeP.setAlpha(Math.round(a * 0.45f));
            c.drawCircle(l[0], l[1], l[2], badgeP);
            badgeP.setStyle(Paint.Style.FILL);
        }
        Drawable ic = t.locked ? lockIcon : lockOpenIcon;
        float s = l[2] * 0.55f;
        ic.setBounds(Math.round(l[0] - s), Math.round(l[1] - s), Math.round(l[0] + s), Math.round(l[1] + s));
        ic.setAlpha(t.locked ? a : Math.round(a * 0.75f));
        ic.draw(c);
    }

    private boolean lockHit(G o, float x, float y) {
        if (o.iconAlpha < 0.5f) return false;
        float dx = x - o.cx, dy = y - o.cy;
        if (o.rot != 0) {
            double an = Math.toRadians(-o.rot);
            float rx = (float) (dx * Math.cos(an) - dy * Math.sin(an));
            float ry = (float) (dx * Math.sin(an) + dy * Math.cos(an));
            dx = rx; dy = ry;
        }
        dx /= o.scale; dy /= o.scale;
        float[] l = lockLocal(o);
        float r = l[2] * 1.35f;
        return (dx - l[0]) * (dx - l[0]) + (dy - l[1]) * (dy - l[1]) <= r * r;
    }

    private void drawStrip(Canvas c) {
        float a = clamp(enterT * 1.5f, 0, 1) * (1f - exitT);
        if (expandIndex >= 0) a *= 1f - expandT;
        if (a <= 0.01f || items.isEmpty()) return;
        float p = pos / step, y = stripY(), gap = stripGap();
        for (int i = 0; i < items.size(); i++) {
            float d = p - i;
            float x = W / 2f + d * gap;
            if (x < -gap || x > W + gap) continue;
            float ad = Math.min(Math.abs(d), 1f);
            float size = lerp(46 * dp, 34 * dp, ad);
            float edge = clamp(1f - (Math.abs(x - W / 2f) - W * 0.36f) / (W * 0.14f), 0, 1);
            float ia = a * edge * lerp(1f, 0.72f, ad);
            drawAppIcon(c, items.get(i), x, y, size, Math.round(255 * ia));
        }
        badgeP.setStyle(Paint.Style.FILL);
        badgeP.setColor(0xFFFAFAFA);
        badgeP.setAlpha(Math.round(230 * a));
        c.drawCircle(W / 2f, y + 31 * dp, 2.6f * dp, badgeP);
    }

    private String ellipsize(String s, float max) {
        if (s == null || max <= 0) return "";
        if (textP.measureText(s) <= max) return s;
        int n = textP.breakText(s, true, max - textP.measureText("…"), null);
        return s.substring(0, Math.max(0, n)) + "…";
    }

    private static int darken(int c) {
        int r = ((c >> 16) & 255) / 4, g = ((c >> 8) & 255) / 4, b = (c & 255) / 4;
        return 0xFF000000 | ((r + 20) << 16) | ((g + 20) << 8) | (b + 22);
    }

    private final Paint iconP = Tasks.aa();
    private final RectF iconR = new RectF();

    /** App icon, round when the user switched round icons on. */
    private void drawAppIcon(Canvas c, TaskItem t, float cx, float cy, float size, int alpha) {
        if (roundIcons) {
            Bitmap b = Tasks.roundIcon(t, Math.round(56 * dp));
            if (b != null) {
                iconR.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f);
                iconP.setAlpha(alpha);
                c.drawBitmap(b, null, iconR, iconP);
                return;
            }
        }
        drawIcon(c, t.icon, cx, cy, size, alpha);
    }

    private void drawIcon(Canvas c, Drawable d, float cx, float cy, float size, int alpha) {
        if (d == null) return;
        int h = Math.round(size / 2f);
        d.setBounds(Math.round(cx) - h, Math.round(cy) - h, Math.round(cx) + h, Math.round(cy) + h);
        d.setAlpha(alpha);
        d.draw(c);
    }

    // ---------------------------------------------------------------- touch

    private int lockAt(float x, float y) {
        buildFrame();
        for (int k = order.size() - 1; k >= 0; k--) {
            int i = order.get(k);
            G o = cache[i];
            if (o.alpha < 0.3f) continue;
            if (lockHit(o, x, y)) return i;
            if (inCard(o, x, y)) return -1;
        }
        return -1;
    }

    private int hit(float x, float y, boolean[] onIcon) {
        buildFrame();
        for (int k = order.size() - 1; k >= 0; k--) {
            int i = order.get(k);
            G o = cache[i];
            if (o.alpha < 0.3f) continue;
            float is = Math.max(o.iconSize, 40 * dp) / 2f + 6 * dp;
            if (o.iconAlpha > 0.5f && Math.abs(x - o.iconCx) < is && Math.abs(y - o.iconCy) < is) { onIcon[0] = true; return i; }
            if (inCard(o, x, y)) { onIcon[0] = false; return i; }
        }
        return -1;
    }

    private boolean inCard(G o, float x, float y) {
        float dx = x - o.cx, dy = y - o.cy;
        if (o.rot != 0) {
            double a = Math.toRadians(-o.rot);
            float rx = (float) (dx * Math.cos(a) - dy * Math.sin(a));
            float ry = (float) (dx * Math.sin(a) + dy * Math.cos(a));
            dx = rx; dy = ry;
        }
        return Math.abs(dx) <= o.w * o.scale / 2f && Math.abs(dy) <= o.h * o.scale / 2f;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (exitT > 0f || enterT < 0.6f || expandIndex >= 0) return true;
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(e);
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = lastX = x; downY = lastY = y;
                dragStartP = step > 0 ? pos / step : 0;
                mode = 0; longPressed = false;
                if (!scroller.isFinished()) { scroller.abortAnimation(); mode = 1; }
                if (posAnim != null && posAnim.isRunning()) { posAnim.cancel(); mode = 1; }
                stripTouch = iconBar && !items.isEmpty() && Math.abs(y - stripY()) < 38 * dp;
                boolean[] ic = new boolean[1];
                downHit = stripTouch ? -1 : hit(x, y, ic);
                if (downHit >= 0 && mode == 0) postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float dx = x - downX, dy = y - downY;
                if (mode == 0 && !longPressed) {
                    boolean h = horizontal();
                    float along = h ? dx : dy, across = h ? dy : dx;
                    if (Math.abs(along) > slop && Math.abs(along) >= Math.abs(across)) mode = 1;
                    else if (Math.abs(across) > slop && downHit >= 0) { mode = 2; dragIndex = downHit; dragOff = 0; }
                    if (mode != 0) {
                        removeCallbacks(longPress);
                        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    }
                }
                if (mode == 1) {
                    float d = horizontal() ? x - lastX : y - lastY;
                    if (stripTouch) d *= step / stripGap(); // icons follow the finger, cards run along
                    float np = pos + d;
                    if (np < 0 || np > maxPos) np = pos + d * 0.35f;
                    pos = clamp(np, -step * 0.3f, maxPos + step * 0.3f);
                    invalidate();
                } else if (mode == 2) {
                    float raw = horizontal() ? y - downY : x - downX;
                    if (horizontal() && raw > 0) raw *= 0.25f;
                    dragOff = raw;
                    invalidate();
                }
                lastX = x; lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                removeCallbacks(longPress);
                vt.computeCurrentVelocity(1000);
                float vx = vt.getXVelocity(), vy = vt.getYVelocity();
                vt.recycle(); vt = null;
                boolean cancel = e.getActionMasked() == MotionEvent.ACTION_CANCEL;
                if (mode == 1) settle((horizontal() ? vx : vy) * (stripTouch ? step / stripGap() : 1f));
                else if (stripTouch) { if (!cancel) tapStrip(x); }
                else if (mode == 2) endDismiss(horizontal() ? vy : vx);
                else if (!cancel && !longPressed) tap(x, y);
                mode = 0;
                return true;
            }
        }
        return true;
    }

    private void tapStrip(float x) {
        float p = pos / step;
        int i = Math.round(p - (x - W / 2f) / stripGap());
        if (i < 0 || i >= items.size()) return;
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        animatePos(i * step, (long) Math.min(520, 300 + 45 * Math.abs(i - p)));
    }

    private void onLongPress() {
        if (mode != 0 || downHit < 0 || downHit >= items.size()) return;
        longPressed = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        buildFrame();
        host.onMenu(items.get(downHit), iconRect(cache[downHit]));
    }

    private RectF iconRect(G o) {
        float h = o.iconSize / 2f;
        return new RectF(o.iconCx - h, o.iconCy - h, o.iconCx + h, o.iconCy + h);
    }

    private void tap(float x, float y) {
        boolean[] ic = new boolean[1];
        int i = hit(x, y, ic);
        if (i < 0) { host.onHome(); return; }
        if (ic[0]) { host.onMenu(items.get(i), iconRect(cache[i])); return; }
        launch(i);
    }

    public void launch(int i) {
        if (i < 0 || i >= items.size()) return;
        buildFrame();
        host.onLaunch(items.get(i), cache[i].rect(new RectF()));
    }

    private void settle(float v) {
        if (snaps()) {
            float p = pos / step;
            // short swipe = exactly one card; a long swipe carries on through the list with its momentum
            float start = Math.round(dragStartP);
            float moved = p - start;                       // cards already dragged by the finger
            float vc = v / step;                           // finger speed, cards per second
            boolean fling = Math.abs(v) / dp > 350;
            float target;
            if (!fling) target = Math.round(p);
            else if (Math.abs(moved) < 0.6f) target = start + Math.signum(v);          // short flick
            else {
                float proj = p + vc * 0.22f;               // where the momentum would carry the list
                target = Math.signum(v) > 0 ? Math.max(Math.round(proj), start + 1) : Math.min(Math.round(proj), start - 1);
            }
            target = clamp(target, 0, Math.max(0, items.size() - 1));
            animatePos(target * step, (long) Math.min(520, 300 + 45 * Math.abs(target - p)));
        } else {
            if (pos < 0 || pos > maxPos) { animatePos(clamp(pos, 0, maxPos), 260); return; }
            if (horizontal()) scroller.fling(Math.round(pos), 0, Math.round(v), 0, 0, Math.round(maxPos), 0, 0);
            else scroller.fling(0, Math.round(pos), 0, Math.round(v), 0, 0, 0, Math.round(maxPos));
            postInvalidateOnAnimation();
        }
    }

    private void animatePos(float to, long ms) {
        if (posAnim != null) posAnim.cancel();
        final float fromP = pos;
        posAnim = ValueAnimator.ofFloat(0, 1);
        posAnim.setDuration(ms);
        posAnim.setInterpolator(new PathInterpolator(0.25f, 0.8f, 0.25f, 1f));
        posAnim.addUpdateListener(a -> { pos = lerp(fromP, to, (float) a.getAnimatedValue()); invalidate(); });
        posAnim.start();
    }

    private void endDismiss(float v) {
        final int i = dragIndex;
        if (i < 0 || i >= items.size()) { dragIndex = -1; dragOff = 0; return; }
        G o = new G(); geo(i, o);
        boolean h = horizontal();
        float size = h ? o.h * o.scale : o.w;
        float thr = h ? 0.3f : (layout == Prefs.VERTICAL ? 0.33f : 0.42f);
        boolean gone;
        float dir;
        if (h) { gone = dragOff < -size * thr || (v < -2500 && dragOff < 0); dir = -1; }
        else {
            gone = Math.abs(dragOff) > size * thr || (Math.abs(v) > 2500 && Math.signum(v) == Math.signum(dragOff));
            dir = Math.signum(dragOff == 0 ? v : dragOff);
        }
        final TaskItem t = items.get(i);
        final float start = dragOff;
        dragIndex = -1; dragOff = 0;
        flyOff.put(t.key(), new float[]{start, 1});
        if (gone) {
            final float end = dir * (h ? H : W);
            ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(200);
            a.setInterpolator(new DecelerateInterpolator());
            a.addUpdateListener(x -> {
                float f = (float) x.getAnimatedValue();
                flyOff.put(t.key(), new float[]{lerp(start, end, f), 1 - f});
                invalidate();
            });
            a.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator an) { removeItem(t); }
            });
            a.start();
            performHapticFeedback(HapticFeedbackConstants.GESTURE_END);
        } else {
            ValueAnimator a = ValueAnimator.ofFloat(start, 0).setDuration(220);
            a.setInterpolator(new DecelerateInterpolator());
            a.addUpdateListener(x -> { flyOff.put(t.key(), new float[]{(float) x.getAnimatedValue(), 1}); invalidate(); });
            a.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator an) { flyOff.remove(t.key()); invalidate(); }
            });
            a.start();
        }
    }

    /** The card flies up and leaves the list, the app keeps running. */
    public void hideItem(TaskItem t) {
        final String k = t.key();
        ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(260);
        a.setInterpolator(new DecelerateInterpolator());
        final boolean h = horizontal();
        a.addUpdateListener(x -> { float f = (float) x.getAnimatedValue(); flyOff.put(k, new float[]{(h ? -H * 0.35f : W * 0.6f) * f, 1 - f}); invalidate(); });
        a.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator an) { removeItem(t, false); }
        });
        a.start();
    }

    /** Puts back cards (keeps the current place in the list). */
    public void setItemsAnimated(List<TaskItem> list) {
        snapshotFrom();
        int f = focusedIndex();
        String fk = f >= 0 && f < items.size() ? items.get(f).key() : null;
        items.clear();
        items.addAll(list);
        computeGeo();
        if (snaps()) { int ni = fk != null ? indexOfKey(fk) : 0; pos = Math.max(0, ni) * step; }
        clampPos();
        startMorph();
        host.onCountChanged(items.size());
    }

    public void removeItem(TaskItem t) { removeItem(t, true); }

    /** Removes a card and slides the others into place. */
    public void removeItem(TaskItem t, boolean close) {
        int i = items.indexOf(t);
        if (i < 0) return;
        flyOff.remove(t.key());
        snapshotFrom();
        int focus = focusedIndex();
        items.remove(i);
        computeGeo();
        if (snaps()) {
            int f = focus > i ? focus - 1 : focus;
            pos = clamp(f, 0, Math.max(0, items.size() - 1)) * step;
        }
        clampPos();
        startMorph();
        if (close) host.onDismiss(t);
        host.onCountChanged(items.size());
    }

    private void snapshotFrom() {
        from.clear();
        for (int k = 0; k < items.size(); k++) {
            G o = new G();
            finalGeo(k, o);
            from.put(items.get(k).key(), o);
        }
    }

    private void startMorph() {
        morphT = 0;
        ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(300);
        a.addUpdateListener(x -> { morphT = (float) x.getAnimatedValue(); invalidate(); });
        a.start();
    }

    /** Close all unlocked cards: they fly away, then the callback runs. */
    public void closeAll(Runnable after) {
        final List<TaskItem> gone = new ArrayList<>();
        for (TaskItem t : items) if (!t.locked) gone.add(t);
        if (gone.isEmpty()) { after.run(); return; }
        final boolean h = horizontal();
        ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(280);
        a.setInterpolator(new PathInterpolator(0.4f, 0f, 0.6f, 1f));
        a.addUpdateListener(x -> {
            float f = (float) x.getAnimatedValue();
            for (int k = 0; k < gone.size(); k++) {
                float delay = Math.min(k * 0.06f, 0.4f);
                float ff = clamp((f - delay) / (1 - delay), 0, 1);
                flyOff.put(gone.get(k).key(), new float[]{(h ? -H * 0.6f : W) * ff, 1 - ff});
            }
            invalidate();
        });
        a.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator an) {
                for (TaskItem t : gone) { items.remove(t); flyOff.remove(t.key()); host.onDismiss(t); }
                computeGeo();
                host.onCountChanged(items.size());
                invalidate();
                after.run();
            }
        });
        a.start();
    }

    /** The card grows to full screen (like opening an app in One UI), then the callback runs. */
    public void expand(int i, Runnable done) {
        if (i < 0 || i >= items.size()) { done.run(); return; }
        expandIndex = i;
        expandT = 0;
        ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(420);
        a.setInterpolator(new PathInterpolator(0.2f, 0f, 0f, 1f));
        a.addUpdateListener(x -> { expandT = (float) x.getAnimatedValue(); invalidate(); });
        a.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator an) { done.run(); }
        });
        a.start();
    }

    public int indexOfKey(String k) {
        for (int i = 0; i < items.size(); i++) if (items.get(i).key().equals(k)) return i;
        return -1;
    }

    public void startEnter(boolean fromApp, int index) {
        enterIndex = index;
        enterFromApp = fromApp;
        enterT = 0;
        ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(fromApp ? 450 : 320);
        a.setInterpolator(null);
        a.addUpdateListener(x -> { enterT = (float) x.getAnimatedValue(); invalidate(); });
        a.start();
    }

    public void startExit(Runnable after) {
        ValueAnimator a = ValueAnimator.ofFloat(0, 1).setDuration(220);
        a.addUpdateListener(x -> { exitT = (float) x.getAnimatedValue(); invalidate(); });
        a.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator an) { if (after != null) after.run(); }
        });
        a.start();
    }

    public void resetExit() { exitT = 0; invalidate(); }

    public void clearShaders() { shaders.clear(); }
}
