package leshugan.recents;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import rikka.shizuku.Shizuku;

/** Settings in the spirit of Home Up › Task changer. */
public final class SettingsActivity extends Activity {
    private float dp;
    private boolean night;
    private int panel, text, sub, accent, divider;
    private LinearLayout list;
    private Row mainRow, miniRow, centerRow, labelRow, circRow, searchRow, barRow, roundRow, shizukuRow, usageRow, blurRow;
    private final List<PreviewView> previews = new ArrayList<>();
    private final Shizuku.OnRequestPermissionResultListener permL = (code, res) -> runOnUiThread(this::refresh);
    private final Shizuku.OnBinderReceivedListener binderL = () -> runOnUiThread(this::refresh);
    private final Shizuku.OnBinderDeadListener deadL = () -> runOnUiThread(this::refresh);

    private static final String[] NAMES = {"Список", "Сетка", "Вертикальный список", "Узкий список", "Наклонная стопка"};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;
        night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        int bg = night ? 0xFF0E1013 : 0xFFEEF1F4;
        panel = night ? 0xFF1C1F23 : 0xFFFFFFFF;
        text = night ? 0xFFF2F3F5 : 0xFF14171A;
        sub = night ? 0xFF9AA1AA : 0xFF6B737D;
        accent = night ? 0xFF5B9BF5 : 0xFF2F80ED;
        divider = night ? 0x14FFFFFF : 0x12000000;

        getWindow().setDecorFitsSystemWindows(false);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(bg);
        sv.setClipToPadding(false);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        sv.setOnApplyWindowInsetsListener((v, in) -> {
            android.graphics.Insets s = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            v.setPadding(s.left, s.top, s.right, s.bottom + px(16));
            return in;
        });

        TextView title = new TextView(this);
        title.setText(R.string.app_name);
        title.setTextColor(text);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setPadding(px(24), px(56), px(24), px(8));
        list.addView(title);
        TextView tsub = new TextView(this);
        tsub.setText("Обновлённый экран недавних приложений из Samsung One UI — пять современных видов, плавные анимации и снимки открытых окон.");
        tsub.setTextColor(sub);
        tsub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tsub.setPadding(px(24), 0, px(24), px(20));
        list.addView(tsub);
        LinearLayout links = new LinearLayout(this);
        links.setPadding(px(18), 0, px(18), px(14));
        links.addView(linkChip("GitHub", "https://github.com/Leshugan/OneUi-HomeUP-Port"));
        links.addView(linkChip("Канал Windrux", "https://t.me/Windrux"));
        list.addView(links);

        LinearLayout p1 = panel();
        mainRow = new Row(p1, "Экран недавних One UI", "", true, null);
        mainRow.onClick = this::toggleMain;

        header("Вид");
        LinearLayout p2 = panel();
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout strip = new LinearLayout(this);
        strip.setPadding(px(12), px(16), px(12), px(14));
        for (int k = 0; k < Prefs.LAYOUTS.length; k++) {
            final int lay = Prefs.LAYOUTS[k];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(px(4), 0, px(4), 0);
            PreviewView pv = new PreviewView(this, lay);
            previews.add(pv);
            cell.addView(pv, new LinearLayout.LayoutParams(px(92), px(196)));
            TextView n = new TextView(this);
            n.setText(NAMES[k]);
            n.setTextColor(text);
            n.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, px(8), 0, 0);
            cell.addView(n, new LinearLayout.LayoutParams(px(96), -2));
            cell.setOnClickListener(v -> { Prefs.sp(this).edit().putInt(Prefs.LAYOUT, lay).apply(); refresh(); });
            strip.addView(cell);
        }
        hs.addView(strip);
        p2.addView(hs);

        header("Подробные настройки");
        LinearLayout p3 = panel();
        miniRow = new Row(p3, "Мини-режим", "Карточки становятся меньше и опускаются к низу экрана — до них удобно дотянуться одной рукой.", true, Prefs.MINI);
        centerRow = new Row(p3, "Текущее приложение в центре", "Сразу показывать в центре приложение, которым вы пользовались, а не предыдущее.", true, Prefs.CENTER);
        labelRow = new Row(p3, "Названия приложений", "Подписи с названием рядом со значком каждого приложения.", true, Prefs.LABEL);
        circRow = new Row(p3, "Круговой список", "Вертикальный список изгибается дугой, как колесо прокрутки.", true, Prefs.CIRCULAR);
        barRow = new Row(p3, "Значки приложений под карточками", "Полоска значков внизу, как в OnePlus: проведите по ней пальцем, чтобы быстро пролистать приложения, или нажмите на значок, чтобы перейти к нему.", true, Prefs.ICONBAR);
        roundRow = new Row(p3, "Круглые значки приложений", "Значки приложений на карточках и в полоске внизу становятся аккуратными кругами, как в One UI.", true, Prefs.ROUND);
        searchRow = new Row(p3, "Кнопка поиска", "Кнопка поиска в верхней части экрана недавних.", true, Prefs.SEARCH);

        header("Доступ");
        LinearLayout p4 = panel();
        shizukuRow = new Row(p4, "Shizuku", "", false, null);
        shizukuRow.onClick = this::askShizuku;
        usageRow = new Row(p4, "История использования", "", false, null);
        usageRow.onClick = () -> {
            try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()))); }
            catch (Throwable t) { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
        };

        blurRow = new Row(p4, "Размытый фон", "", false, null);
        blurRow.onClick = () -> {
            if (getWindowManager().isCrossWindowBlurEnabled() || android.os.Environment.isExternalStorageManager()) return;
            try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, android.net.Uri.parse("package:" + getPackageName()))); }
            catch (Throwable t) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
        };

        LinearLayout p5 = panel();
        Row show = new Row(p5, "Открыть недавние", "Показать экран недавних прямо сейчас.", false, null);
        show.onClick = () -> startActivity(new Intent(this, RecentsActivity.class).setAction(RecentsActivity.ACTION_SHOW)
                .putExtra(RecentsActivity.EXTRA_FG, "-").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

        setContentView(sv);
        Tasks.ensureBinder(this);
        WindowInsetsController ic = getWindow().getInsetsController();
        int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
        if (ic != null) ic.setSystemBarsAppearance(night ? 0 : light, light);
        try {
            Shizuku.addRequestPermissionResultListener(permL);
            Shizuku.addBinderReceivedListenerSticky(binderL);
            Shizuku.addBinderDeadListener(deadL);
        } catch (Throwable ignored) {}
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try {
            Shizuku.removeRequestPermissionResultListener(permL);
            Shizuku.removeBinderReceivedListener(binderL);
            Shizuku.removeBinderDeadListener(deadL);
        } catch (Throwable ignored) {}
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private int px(float v) { return Math.round(v * dp); }

    private TextView linkChip(String label, String url) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(accent);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(px(16), px(8), px(16), px(8));
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(18 * dp);
        d.setColor(night ? 0x1F5B9BF5 : 0x142F80ED);
        t.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(px(6), 0, px(6), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            catch (Throwable e) { Toast.makeText(this, url, Toast.LENGTH_SHORT).show(); }
        });
        return t;
    }

    private void header(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(accent);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setPadding(px(30), px(18), px(24), px(8));
        list.addView(t);
    }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable d = new GradientDrawable();
        d.setColor(panel);
        d.setCornerRadius(26 * dp);
        p.setBackground(d);
        p.setClipToOutline(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(px(12), px(4), px(12), px(4));
        list.addView(p, lp);
        return p;
    }

    private boolean serviceOn() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        String me = new ComponentName(this, NavService.class).flattenToString();
        String shortMe = getPackageName() + "/.NavService";
        for (String x : TextUtils.split(s, ":")) if (x.equalsIgnoreCase(me) || x.equalsIgnoreCase(shortMe)) return true;
        return false;
    }

    private void toggleMain() {
        if (!serviceOn()) {
            Toast.makeText(this, "Найдите «Недавние One UI» в списке и включите", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        Prefs.sp(this).edit().putBoolean(Prefs.ENABLED, !Prefs.enabled(this)).apply();
        refresh();
    }

    private void askShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) startActivity(i);
                else Toast.makeText(this, "Установите и запустите Shizuku", Toast.LENGTH_LONG).show();
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(1);
        } catch (Throwable t) {
            Toast.makeText(this, "Shizuku недоступен", Toast.LENGTH_SHORT).show();
        }
    }

    private void refresh() {
        boolean svc = serviceOn();
        mainRow.setChecked(svc && Prefs.enabled(this));
        mainRow.setSummary(!svc ? "Выключено. Нажмите и включите службу «Недавние One UI» — после этого кнопка «Недавние» будет открывать новый экран."
                : Prefs.enabled(this) ? "Кнопка «Недавние» открывает экран недавних в стиле Samsung One UI."
                : "Кнопка «Недавние» работает как обычно.");
        int lay = Prefs.layout(this);
        for (int k = 0; k < previews.size(); k++) previews.get(k).setSelectedState(Prefs.LAYOUTS[k] == lay, accent);
        boolean flat = lay == Prefs.VERTICAL || lay == Prefs.SLIM;
        miniRow.setEnabled(!flat);
        centerRow.setEnabled(lay == Prefs.LIST || lay == Prefs.TILT);
        labelRow.setEnabled(!flat);
        circRow.setEnabled(lay == Prefs.VERTICAL);
        barRow.setEnabled(lay == Prefs.LIST || lay == Prefs.TILT);
        for (Row r : new Row[]{miniRow, centerRow, labelRow, circRow, barRow, roundRow, searchRow}) r.load();

        boolean ping;
        try { ping = Shizuku.pingBinder(); } catch (Throwable t) { ping = false; }
        boolean granted = Tasks.shizukuReady();
        shizukuRow.setSummary(granted ? "Подключено: видны снимки окон, а закрытие карточки по-настоящему закрывает задачу."
                : ping ? "Нажмите, чтобы разрешить. Даёт снимки окон и настоящее закрытие задач."
                : "Не запущен. Без Shizuku вместо снимков окон показываются значки приложений.");
        shizukuRow.setValue(granted ? "Вкл." : "Выкл.");
        boolean usage = Tasks.usageAllowed(this);
        usageRow.setSummary(usage ? "Разрешено. Используется, когда Shizuku не запущен."
                : "Нужна, когда Shizuku не запущен: по ней строится список приложений.");
        usageRow.setValue(usage ? "Вкл." : "Выкл.");
        boolean sys = getWindowManager().isCrossWindowBlurEnabled(), files = android.os.Environment.isExternalStorageManager();
        blurRow.setSummary(sys ? "Работает системное размытие: за карточками размыт рабочий стол."
                : files ? "Обои за карточками размываются, как в One UI."
                : "Системное размытие выключено. Нажмите и разрешите доступ к файлам — он нужен только чтобы прочитать обои и размыть их за карточками.");
        blurRow.setValue(sys || files ? "Вкл." : "Выкл.");
    }

    /** One settings line: title, summary, optional switch or value on the right. */
    private final class Row {
        final LinearLayout v;
        final TextView title, summary, value;
        final Switch sw;
        final String key;
        Runnable onClick;
        boolean enabled = true;

        Row(LinearLayout parent, String t, String s, boolean withSwitch, String key) {
            this.key = key;
            if (parent.getChildCount() > 0) {
                View d = new View(SettingsActivity.this);
                d.setBackgroundColor(divider);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, Math.max(1, px(0.7f)));
                dl.setMargins(px(24), 0, px(24), 0);
                parent.addView(d, dl);
            }
            v = new LinearLayout(SettingsActivity.this);
            v.setOrientation(LinearLayout.HORIZONTAL);
            v.setGravity(Gravity.CENTER_VERTICAL);
            v.setPadding(px(24), px(15), px(20), px(15));
            v.setMinimumHeight(px(64));
            TypedValue tv = new TypedValue();
            getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
            v.setBackgroundResource(tv.resourceId);
            LinearLayout col = new LinearLayout(SettingsActivity.this);
            col.setOrientation(LinearLayout.VERTICAL);
            title = new TextView(SettingsActivity.this);
            title.setText(t);
            title.setTextColor(text);
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
            col.addView(title);
            summary = new TextView(SettingsActivity.this);
            summary.setText(s);
            summary.setTextColor(sub);
            summary.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            summary.setPadding(0, px(2), 0, 0);
            summary.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
            col.addView(summary);
            v.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            value = new TextView(SettingsActivity.this);
            value.setTextColor(accent);
            value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            value.setPadding(px(12), 0, 0, 0);
            value.setVisibility(View.GONE);
            v.addView(value);
            if (withSwitch) {
                sw = new Switch(SettingsActivity.this);
                int off = night ? 0xFF6A7078 : 0xFFB9C0C8;
                int[][] st = {{android.R.attr.state_checked}, {}};
                sw.setThumbTintList(new ColorStateList(st, new int[]{0xFFFFFFFF, 0xFFFFFFFF}));
                sw.setTrackTintList(new ColorStateList(st, new int[]{accent, off}));
                sw.setClickable(false);
                sw.setFocusable(false);
                v.addView(sw);
            } else sw = null;
            v.setOnClickListener(x -> {
                if (!enabled) return;
                if (this.key != null) {
                    boolean nv = !sw.isChecked();
                    Prefs.sp(SettingsActivity.this).edit().putBoolean(this.key, nv).apply();
                    sw.setChecked(nv);
                } else if (onClick != null) onClick.run();
            });
            parent.addView(v);
        }

        void load() {
            if (key != null && sw != null) sw.setChecked(Prefs.sp(SettingsActivity.this).getBoolean(key, Prefs.SEARCH.equals(key) || Prefs.ICONBAR.equals(key)));
        }

        void setChecked(boolean c) { if (sw != null) sw.setChecked(c); }
        void setSummary(String s) { summary.setText(s); summary.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE); }
        void setValue(String s) { value.setText(s); value.setVisibility(View.VISIBLE); }
        void setEnabled(boolean e) { enabled = e; v.setAlpha(e ? 1f : 0.4f); }
    }
}
