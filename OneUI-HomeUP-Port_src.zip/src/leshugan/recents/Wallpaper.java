package leshugan.recents;

import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

/** Small copy of the home wallpaper, kept ready so the recents screen can show it blurred from the first frame. */
final class Wallpaper {
    private static volatile Bitmap small;
    private static volatile int id = -1;

    static Bitmap get(Context c) {
        Bitmap b = small;
        if (b == null) return null;
        return currentId(c) == id ? b : null;
    }

    private static int currentId(Context c) {
        try { return WallpaperManager.getInstance(c).getWallpaperId(WallpaperManager.FLAG_SYSTEM); } catch (Throwable t) { return -2; }
    }

    /** Loads (or reloads) the wallpaper; call off the main thread. */
    static synchronized Bitmap load(Context c) {
        int cur = currentId(c);
        if (small != null && cur == id) return small;
        try {
            Drawable d = WallpaperManager.getInstance(c).getDrawable();
            if (d == null) return null;
            int w = Math.max(1, c.getResources().getDisplayMetrics().widthPixels / 6);
            int h = Math.max(1, c.getResources().getDisplayMetrics().heightPixels / 6);
            int iw = Math.max(1, d.getIntrinsicWidth()), ih = Math.max(1, d.getIntrinsicHeight());
            float s = Math.max(w / (float) iw, h / (float) ih);
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            int dw = Math.round(iw * s), dh = Math.round(ih * s);
            d.setBounds((w - dw) / 2, (h - dh) / 2, (w - dw) / 2 + dw, (h - dh) / 2 + dh);
            d.draw(cv);
            blur(b, 7);
            blur(b, 7);
            blur(b, 7);
            small = b;
            id = cur;
            return b;
        } catch (Throwable t) {
            android.util.Log.w(Tasks.TAG, "wallpaper: " + t);
            return null;
        }
    }

    /** One pass of a box blur, done once and cached, so the recents screen draws a plain picture (no GPU blur per frame). */
    private static void blur(Bitmap b, int r) {
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h], tmp = new int[w * h];
        b.getPixels(px, 0, w, 0, 0, w, h);
        for (int pass = 0; pass < 2; pass++) {
            int[] src = pass == 0 ? px : tmp, dst = pass == 0 ? tmp : px;
            int len = pass == 0 ? w : h, lines = pass == 0 ? h : w;
            for (int l = 0; l < lines; l++) {
                int sr = 0, sg = 0, sb = 0, n = 0;
                for (int k = -r; k <= r; k++) { int i = Math.max(0, Math.min(len - 1, k)); int c = src[pass == 0 ? l * w + i : i * w + l]; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; n++; }
                for (int i = 0; i < len; i++) {
                    dst[pass == 0 ? l * w + i : i * w + l] = 0xFF000000 | ((sr / n) << 16) | ((sg / n) << 8) | (sb / n);
                    int out = Math.max(0, Math.min(len - 1, i - r)), in = Math.max(0, Math.min(len - 1, i + r + 1));
                    int co = src[pass == 0 ? l * w + out : out * w + l], ci = src[pass == 0 ? l * w + in : in * w + l];
                    sr += ((ci >> 16) & 255) - ((co >> 16) & 255); sg += ((ci >> 8) & 255) - ((co >> 8) & 255); sb += (ci & 255) - (co & 255);
                }
            }
        }
        b.setPixels(px, 0, w, 0, 0, w, h);
    }

    private Wallpaper() {}
}
