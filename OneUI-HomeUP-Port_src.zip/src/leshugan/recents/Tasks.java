package leshugan.recents;

import android.app.ActivityManager;
import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.hardware.HardwareBuffer;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Process;
import android.util.Log;
import android.util.LruCache;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuBinderWrapper;
import rikka.shizuku.SystemServiceHelper;

/** Recent tasks: real system tasks through Shizuku, or the usage history when Shizuku is absent. */
public final class Tasks {
    static final String TAG = "OneUIRecents";
    private static Object atm;
    private static boolean bypassDone;
    /** Thumbnail cache so the screen opens with pictures right away. */
    static final LruCache<String, Bitmap> THUMBS = new LruCache<String, Bitmap>(64 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getAllocationByteCount(); }
    };

    /** Asks Shizuku to hand over its connection when it was started before this app. */
    public static void ensureBinder(Context c) {
        try { if (!Shizuku.pingBinder()) rikka.shizuku.ShizukuProvider.requestBinderForNonProviderProcess(c); } catch (Throwable ignored) {}
    }

    public static boolean shizukuReady() {
        try {
            return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    public static boolean usageAllowed(Context c) {
        AppOpsManager ao = c.getSystemService(AppOpsManager.class);
        return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName())
                == AppOpsManager.MODE_ALLOWED;
    }

    private static synchronized Object atm() throws Exception {
        if (!bypassDone) {
            try { org.lsposed.hiddenapibypass.HiddenApiBypass.addHiddenApiExemptions("L"); } catch (Throwable ignored) {}
            bypassDone = true;
        }
        if (atm == null) {
            IBinder b = new ShizukuBinderWrapper(SystemServiceHelper.getSystemService("activity_task"));
            Class<?> stub = Class.forName("android.app.IActivityTaskManager$Stub");
            atm = stub.getMethod("asInterface", IBinder.class).invoke(null, b);
        }
        return atm;
    }

    static synchronized void reset() { atm = null; }

    /** Calls a binder method by name; ints/booleans/Bundles are taken from hints in order. */
    private static Object call(String name, Object... hints) throws Exception {
        Object a = atm();
        Method m = null;
        for (Method x : a.getClass().getMethods()) {
            if (x.getName().equals(name) && (m == null || x.getParameterTypes().length < m.getParameterTypes().length)) m = x;
        }
        if (m == null) throw new NoSuchMethodException(name);
        Class<?>[] pt = m.getParameterTypes();
        Object[] args = new Object[pt.length];
        int ii = 0, bi = 0;
        List<Integer> ints = new ArrayList<>(); List<Boolean> bools = new ArrayList<>(); Bundle bundle = null;
        for (Object h : hints) {
            if (h instanceof Integer) ints.add((Integer) h);
            else if (h instanceof Boolean) bools.add((Boolean) h);
            else if (h instanceof Bundle) bundle = (Bundle) h;
        }
        for (int i = 0; i < pt.length; i++) {
            Class<?> t = pt[i];
            if (t == int.class) args[i] = ii < ints.size() ? ints.get(ii++) : 0;
            else if (t == boolean.class) args[i] = bi < bools.size() ? bools.get(bi++) : false;
            else if (t == long.class) args[i] = 0L;
            else if (t == float.class) args[i] = 0f;
            else if (t == Bundle.class) args[i] = bundle;
            else if (t == String.class) args[i] = "com.android.shell";
            else args[i] = null;
        }
        try {
            return m.invoke(a, args);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable c = e.getCause();
            if (c instanceof android.os.DeadObjectException) reset();
            throw c instanceof Exception ? (Exception) c : e;
        }
    }

    private static Object field(Object o, String f) {
        for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
            try { java.lang.reflect.Field fl = c.getDeclaredField(f); fl.setAccessible(true); return fl.get(o); }
            catch (Throwable ignored) {}
        }
        return null;
    }

    private static int activityType(Object ti) {
        try { Method m = ti.getClass().getMethod("getActivityType"); return (Integer) m.invoke(ti); }
        catch (Throwable t) {
            Object f = field(ti, "topActivityType");
            return f instanceof Integer ? (Integer) f : 0;
        }
    }

    private static Set<String> homePackages(Context c) {
        Set<String> s = new HashSet<>();
        Intent h = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo def = c.getPackageManager().resolveActivity(h, PackageManager.MATCH_DEFAULT_ONLY);
        if (def != null && def.activityInfo != null) s.add(def.activityInfo.packageName);
        s.add(c.getPackageName());
        s.add("com.android.systemui");
        return s;
    }

    /** Newest first. */
    public static List<TaskItem> load(Context c) {
        List<TaskItem> out = new ArrayList<>();
        if (shizukuReady()) {
            try { loadShizuku(c, out); return arrange(c, out); }
            catch (Throwable t) { Log.w(TAG, "shizuku tasks failed", t); out.clear(); reset(); }
        }
        if (usageAllowed(c)) loadUsage(c, out);
        return arrange(c, out);
    }

    private static void loadShizuku(Context c, List<TaskItem> out) throws Exception {
        int user = Process.myUserHandle().hashCode();
        Object slice = call("getRecentTasks", 60, 0x0002, user);
        List<?> list = (List<?>) slice.getClass().getMethod("getList").invoke(slice);
        Set<String> home = homePackages(c);
        Set<String> locked = Prefs.locked(c);
        PackageManager pm = c.getPackageManager();
        for (Object o : list) {
            ActivityManager.RecentTaskInfo ri = (ActivityManager.RecentTaskInfo) o;
            Intent bi = ri.baseIntent;
            ComponentName cn = ri.baseActivity != null ? ri.baseActivity : (bi != null ? bi.getComponent() : null);
            if (cn == null && ri.topActivity != null) cn = ri.topActivity;
            if (cn == null) continue;
            if (home.contains(cn.getPackageName())) continue;
            if (bi != null && bi.hasCategory(Intent.CATEGORY_HOME) && Intent.ACTION_MAIN.equals(bi.getAction()) && bi.getCategories().size() == 1 && home.contains(cn.getPackageName())) continue;
            int type = activityType(ri);
            if (type > 1) continue; // home, recents, assistant, dream
            if (cn.getPackageName().equals("com.android.settings") && cn.getClassName().contains("FallbackHome")) continue;
            TaskItem t = new TaskItem();
            t.taskId = ri.taskId;
            t.comp = cn;
            t.pkg = cn.getPackageName();
            t.baseIntent = bi;
            Object la = field(ri, "lastActiveTime");
            t.lastActive = la instanceof Long ? (Long) la : 0;
            t.locked = locked.contains(t.pkg);
            fill(pm, t);
            t.thumb = THUMBS.get(t.key());
            out.add(t);
        }
    }

    private static void loadUsage(Context c, List<TaskItem> out) {
        UsageStatsManager um = c.getSystemService(UsageStatsManager.class);
        long now = System.currentTimeMillis();
        UsageEvents ev = um.queryEvents(now - 3L * 24 * 3600 * 1000, now);
        HashMap<String, Long> last = new HashMap<>();
        UsageEvents.Event e = new UsageEvents.Event();
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e);
            if (e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) last.put(e.getPackageName(), e.getTimeStamp());
        }
        Set<String> home = homePackages(c);
        Set<String> locked = Prefs.locked(c);
        PackageManager pm = c.getPackageManager();
        List<String> pk = new ArrayList<>(last.keySet());
        pk.sort((a, b) -> Long.compare(last.get(b), last.get(a)));
        for (String p : pk) {
            if (home.contains(p)) continue;
            Intent li = pm.getLaunchIntentForPackage(p);
            if (li == null) continue;
            TaskItem t = new TaskItem();
            t.pkg = p;
            t.comp = li.getComponent();
            t.baseIntent = li;
            t.lastActive = last.get(p);
            t.locked = locked.contains(p);
            fill(pm, t);
            out.add(t);
            if (out.size() >= 40) break;
        }
    }

    private static void fill(PackageManager pm, TaskItem t) {
        try {
            ApplicationInfo ai = pm.getApplicationInfo(t.pkg, 0);
            t.label = String.valueOf(ai.loadLabel(pm));
            Drawable d = null;
            try { d = pm.getActivityIcon(t.comp); } catch (Throwable ignored) {}
            t.icon = d != null ? d : ai.loadIcon(pm);
        } catch (Throwable e) {
            t.label = t.pkg;
            t.icon = pm.getDefaultActivityIcon();
        }
        t.color = iconColor(t.icon);
    }

    /** Pale tint of the icon colour, used for cards without a picture. */
    static int iconColor(Drawable d) {
        try {
            Bitmap b = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, 8, 8);
            d.draw(cv);
            long r = 0, g = 0, bl = 0, n = 0;
            for (int x = 0; x < 8; x++) for (int y = 0; y < 8; y++) {
                int p = b.getPixel(x, y);
                if ((p >>> 24) < 128) continue;
                r += (p >> 16) & 255; g += (p >> 8) & 255; bl += p & 255; n++;
            }
            if (n == 0) return 0xFFF2F4F7;
            int R = (int) (r / n), G = (int) (g / n), B = (int) (bl / n);
            R = 255 - (255 - R) / 5; G = 255 - (255 - G) / 5; B = 255 - (255 - B) / 5;
            return 0xFF000000 | (R << 16) | (G << 8) | B;
        } catch (Throwable t) { return 0xFFF2F4F7; }
    }

    /** Task picture scaled down for drawing; null when not available. */
    public static Bitmap snapshot(TaskItem t, boolean takeNew, int maxW) {
        if (t.taskId < 0 || !shizukuReady()) return null;
        try {
            Object snap = null;
            if (takeNew) {
                try { snap = call("takeTaskSnapshot", t.taskId, false); } catch (Throwable e) { Log.w(TAG, "takeTaskSnapshot: " + e); }
            }
            if (snap == null) snap = call("getTaskSnapshot", t.taskId, false);
            if (snap == null) return null;
            HardwareBuffer hb = (HardwareBuffer) snap.getClass().getMethod("getHardwareBuffer").invoke(snap);
            if (hb == null) return null;
            ColorSpace cs = null;
            try { cs = (ColorSpace) snap.getClass().getMethod("getColorSpace").invoke(snap); } catch (Throwable ignored) {}
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, cs);
            if (hw == null) return null;
            float s = Math.min(1f, maxW / (float) hw.getWidth());
            int w = Math.max(1, Math.round(hw.getWidth() * s)), h = Math.max(1, Math.round(hw.getHeight() * s));
            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            hb.close();
            if (sw == null) return null;
            Bitmap out = s < 1f ? Bitmap.createScaledBitmap(sw, w, h, true) : sw;
            if (out != sw) sw.recycle();
            THUMBS.put(t.key(), out);
            return out;
        } catch (Throwable e) {
            Log.w(TAG, "snapshot " + t.taskId + " failed: " + e);
            return null;
        }
    }

    /** Opens the task. Returns false when it could not be opened at all. */
    public static boolean launch(Context c, TaskItem t, Bundle opts) {
        if (t.taskId >= 0 && shizukuReady()) {
            try {
                Object r = call("startActivityFromRecents", t.taskId, opts);
                if (r instanceof Integer && (Integer) r >= 0) return true;
                Log.w(TAG, "startActivityFromRecents=" + r);
            } catch (Throwable e) { Log.w(TAG, "startActivityFromRecents failed: " + e); }
            try {
                call("startActivityFromRecents", t.taskId);
                return true;
            } catch (Throwable e) { Log.w(TAG, "startActivityFromRecents (no options) failed: " + e); }
            try {
                call("moveTaskToFront", t.taskId, 0, opts);
                return true;
            } catch (Throwable e) { Log.w(TAG, "moveTaskToFront failed: " + e); }
        }
        try {
            Intent i = t.baseIntent != null ? new Intent(t.baseIntent) : c.getPackageManager().getLaunchIntentForPackage(t.pkg);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i, opts);
            return true;
        } catch (Throwable e) {
            Log.w(TAG, "launch fallback failed: " + e);
            return false;
        }
    }

    /**
     * Real close: the system task is removed (the app is closed). Without Shizuku the task cannot be
     * removed, so the card is hidden until the app is used again and its background process is stopped.
     */
    public static synchronized void remove(Context c, TaskItem t) {
        THUMBS.remove(t.key());
        java.util.LinkedHashMap<String, Long> hid = readHidden(c);
        List<String> ord = readOrder(c);
        ord.remove(t.key());
        boolean done = false;
        if (t.taskId >= 0 && shizukuReady()) {
            try { call("removeTask", t.taskId); done = true; } catch (Throwable e) { Log.w(TAG, "removeTask failed: " + e); }
        }
        if (!done) {
            hid.put(t.key(), t.lastActive > 0 ? t.lastActive : System.currentTimeMillis());
            try { c.getSystemService(ActivityManager.class).killBackgroundProcesses(t.pkg); } catch (Throwable ignored) {}
        }
        save(c, ord, hid);
    }

    private static Boolean oplus;

    /** ColorOS / OxygenOS (OPPO, OnePlus, realme firmware). */
    public static boolean isOplus() {
        if (oplus != null) return oplus;
        boolean r = false;
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method g = sp.getMethod("get", String.class, String.class);
            for (String k : new String[]{"ro.build.version.oplusrom", "ro.build.version.opporom", "ro.oxygen.version", "ro.rom.version"})
                if (!String.valueOf(g.invoke(null, k, "")).isEmpty() && !k.equals("ro.rom.version")) { r = true; break; }
        } catch (Throwable ignored) {}
        if (!r) {
            String m = (android.os.Build.MANUFACTURER + " " + android.os.Build.BRAND).toLowerCase();
            r = m.contains("oneplus") || m.contains("oppo") || m.contains("realme");
        }
        oplus = r;
        return r;
    }

    private static List<String> readOrder(Context c) {
        String s = Prefs.sp(c).getString(Prefs.ORDER, "");
        List<String> l = new ArrayList<>();
        for (String x : s.split(",")) if (!x.isEmpty()) l.add(x);
        return l;
    }

    private static java.util.LinkedHashMap<String, Long> readHidden(Context c) {
        java.util.LinkedHashMap<String, Long> m = new java.util.LinkedHashMap<>();
        for (String x : Prefs.sp(c).getString(Prefs.HIDDEN, "").split(",")) {
            int k = x.lastIndexOf('=');
            if (k > 0) try { m.put(x.substring(0, k), Long.parseLong(x.substring(k + 1))); } catch (Throwable ignored) {}
        }
        return m;
    }

    private static void save(Context c, List<String> ord, java.util.Map<String, Long> hid) {
        StringBuilder h = new StringBuilder();
        for (java.util.Map.Entry<String, Long> e : hid.entrySet()) { if (h.length() > 0) h.append(','); h.append(e.getKey()).append('=').append(e.getValue()); }
        Prefs.sp(c).edit().putString(Prefs.ORDER, android.text.TextUtils.join(",", ord)).putString(Prefs.HIDDEN, h.toString()).apply();
    }

    /**
     * Cards keep their place: a new app goes to the newest end, switching between apps does not
     * reorder anything. Closed cards stay hidden until the app is used again.
     * Input is newest-first by real use; output is newest-first by place.
     */
    private static synchronized List<TaskItem> arrange(Context c, List<TaskItem> raw) {
        for (int i = 0; i < raw.size(); i++) raw.get(i).recency = i;
        List<String> ord = readOrder(c);
        java.util.LinkedHashMap<String, Long> hid = readHidden(c);
        HashMap<String, TaskItem> by = new HashMap<>();
        List<TaskItem> visible = new ArrayList<>();
        for (TaskItem t : raw) {
            String k = t.key();
            Long h = hid.get(k);
            if (h != null) {
                if (t.lastActive > h) { hid.remove(k); ord.remove(k); }
                else continue;
            }
            by.put(k, t);
            visible.add(t);
        }
        HashSet<String> alive = new HashSet<>();
        for (TaskItem t : raw) alive.add(t.key());
        hid.keySet().retainAll(alive);
        ord.retainAll(by.keySet());
        for (int i = visible.size() - 1; i >= 0; i--) {
            String k = visible.get(i).key();
            if (!ord.contains(k)) ord.add(k);
        }
        save(c, ord, hid);
        List<TaskItem> out = new ArrayList<>();
        for (int i = ord.size() - 1; i >= 0; i--) out.add(by.get(ord.get(i)));
        return out;
    }

    /** Circular app icon: adaptive icons are rebuilt from their layers, others are cut to a circle. */
    public static Bitmap roundIcon(TaskItem t, int size) {
        if (t.round != null) return t.round;
        try {
            Bitmap sq = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(sq);
            Drawable d = t.icon;
            if (d instanceof android.graphics.drawable.AdaptiveIconDrawable) {
                android.graphics.drawable.AdaptiveIconDrawable a = (android.graphics.drawable.AdaptiveIconDrawable) d;
                int e = Math.round(size * 0.25f); // layers are 108 dp, the visible part is the middle 72 dp
                for (Drawable l : new Drawable[]{a.getBackground(), a.getForeground()}) {
                    if (l == null) continue;
                    l.setBounds(-e, -e, size + e, size + e);
                    l.draw(c);
                }
            } else {
                c.drawColor(0xFFFFFFFF);
                int m = Math.round(size * 0.12f);
                d.setBounds(m, m, size - m, size - m);
                d.draw(c);
            }
            Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Paint p = aa();
            p.setShader(new android.graphics.BitmapShader(sq, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP));
            new Canvas(out).drawCircle(size / 2f, size / 2f, size / 2f, p);
            sq.recycle();
            t.round = out;
            return out;
        } catch (Throwable e) { return null; }
    }

    static Paint aa() { return new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG); }

    private Tasks() {}
}
